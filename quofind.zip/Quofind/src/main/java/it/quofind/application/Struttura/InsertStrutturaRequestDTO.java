package it.quofind.application.Struttura;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class InsertStrutturaRequestDTO {
	
	private String descrizione;
	@NotNull(message = "il campo idlocalita non puo esser vuoto")
	private Long idLocalita;
	@NotNull(message = "il campo idcompany non puo esser vuoto")
	private Long idCompany;

}
