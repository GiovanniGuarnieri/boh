package it.quofind.application.Acquisto;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import it.quofind.application.errors.NotFoundException;



@RestController
@RequestMapping("/acquisto")
public class AcquistoController {
	
	@Autowired
	AcquistoService acquistoService;

	
	@Operation (summary = "Inserisce un acquisto nel db", description = "inserisce un acquisto nel db ")
	@ApiResponse(responseCode = "200" , description = "acquisto inserito")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated ")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@PostMapping(path = "/inserisci-acquisto" ,produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity<?> inserisciAcquisto(@Valid @RequestBody InsertAcquistoRequestDTO dto) throws NotFoundException  {
		acquistoService.insertAcquisto(dto);
			return ResponseEntity.ok("Acquisto inserito");
		}
	@Operation (summary = "modifica un acquisto ", description = "modifica un acquisto  ")
	@ApiResponse(responseCode = "200" , description = "modifica avvenuta")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated  ")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/modifica-acquisto/{id}")
	public ResponseEntity<?> modificaCliente(@Valid @PathVariable Long id, @RequestBody InsertAcquistoRequestDTO dto) throws NotFoundException {
		acquistoService.updateAcquisto(id, dto);
		return ResponseEntity.ok("acquisto modificato");
	}


	@Operation (summary = "elimina un acquisto", description = "elimina un acquisto")
	@ApiResponse(responseCode = "200" , description = "eliminazione avvenuta")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated ")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@DeleteMapping("/elimina-acquisto")
	public ResponseEntity<?> eliminaCliente(@Valid Long id ) throws NotFoundException {
		acquistoService.delete(id);
		return ResponseEntity.ok("acquisto eliminato");
	}
	
	@Operation (summary = "ritorna tutti gli acquisti ", description = "ritorna la lista di tutti gli acquisti ")
	@ApiResponse(responseCode = "200" , description = "lista acquisti")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/get-all")
	public ResponseEntity<Page<Acquisto>> tuttiClienti(Pageable page) {
		return ResponseEntity.ok(acquistoService.findAll(page));
	}
	
	@Operation (summary = "ritorna un acquisto ", description = "ritorna un acquisto ")
	@ApiResponse(responseCode = "200" , description = "acquisto")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/get-byid/{id}")
	public ResponseEntity<Acquisto> tuttiAcquisti(@Valid @PathVariable Long id) throws NotFoundException {
		return ResponseEntity.ok(acquistoService.findById(id));
	}
	
}
