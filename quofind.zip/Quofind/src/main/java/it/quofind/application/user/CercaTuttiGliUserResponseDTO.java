package it.quofind.application.user;

import java.util.List;


import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CercaTuttiGliUserResponseDTO {
	private int UserTrovati;
	List<User>elencoUser;

}
