package it.quofind.application.company;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface CompanyRepository extends PagingAndSortingRepository<Company, Long> {
	@Transactional
	@Query("select  c from Company c join fetch c.users u where u.username=?1")
	public Company findByUserName(String userName);
	
	public boolean existsByCompanyName(String companyName);
}
