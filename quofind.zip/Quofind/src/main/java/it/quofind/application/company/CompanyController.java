package it.quofind.application.company;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.quofind.application.cashBack.CashBack;
import it.quofind.application.cashBack.InsertCashBackRequestDTO;
import it.quofind.application.errors.ElementAlreadyPresentException;
import it.quofind.application.errors.NotFoundException;

@RestController
@RequestMapping("/company")
public class CompanyController {
	
	@Autowired
	CompanyService companyService;
	
	

	@Operation (summary = "Inserisce una company", description = "inserisce un company")
	@ApiResponse(responseCode = "200" , description = "company inserito")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated ")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@PostMapping(path = "/inserisci-company" ,produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity<?> inserisciCompany(@Valid @RequestBody InsertCompanyRequestDTO dto) throws NotFoundException, ElementAlreadyPresentException  {
		companyService.insertCompany(dto);
			return ResponseEntity.ok("Company inserito");
		}
	
	@Operation (summary = "modifica un Company ", description = "modifica un Company ")
	@ApiResponse(responseCode = "200" , description = "modifica avvenuta")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated  ")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/modifica-company/{id}")
	public ResponseEntity<?> modificaCompany(@Valid @PathVariable Long id, @RequestBody InsertCompanyRequestDTO dto) throws NotFoundException {
		companyService.UpdateCompany(id, dto);
		return ResponseEntity.ok("Company modificato");
	}


	@Operation (summary = "elimina un Company", description = "elimina un Company")
	@ApiResponse(responseCode = "200" , description = "eliminazione avvenuta")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated ")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@DeleteMapping("/elimina-company")
	public ResponseEntity<?> eliminaCompany(@Valid Long id ) throws NotFoundException {
		companyService.deleteById(id);
		return ResponseEntity.ok("Company eliminato");
	}
	
	@Operation (summary = "ritorna tutti Company ", description = "ritorna la lista di tutti Company")
	@ApiResponse(responseCode = "200" , description = "lista Company")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/get-all")
	public ResponseEntity<Page<Company>> tuttiCompany(Pageable page) {
		return ResponseEntity.ok(companyService.findAll(page));
	}
	
	@Operation (summary = "ritorna un Company ", description = "ritorna un Company")
	@ApiResponse(responseCode = "200" , description = "company")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/get-byid/{id}")
	public ResponseEntity<Company> getbyid(@Valid @PathVariable Long id) throws NotFoundException {
		return ResponseEntity.ok(companyService.findById(id));
	}
	
	
	
	
	
	

}
