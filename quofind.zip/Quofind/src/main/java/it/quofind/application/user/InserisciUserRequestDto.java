package it.quofind.application.user;



import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.validation.constraints.NotBlank;



import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class InserisciUserRequestDto {




	private Long companyId;
	@Enumerated(EnumType.STRING)
	private UserTypeEnum userType;

	public Long getCompanyId() {
		return companyId;
	}
	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}
	@NotBlank
	private String username;
	@NotBlank
	private String password;
	@NotBlank
	private String email;
	private String nome;
	private String cognome;




}
