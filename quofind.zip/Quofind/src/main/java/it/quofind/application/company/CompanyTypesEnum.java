package it.quofind.application.company;

public enum CompanyTypesEnum {

}
