package it.quofind.application.user;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.validation.constraints.NotBlank;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

import it.quofind.application.cashBack.CashBack;
import it.quofind.application.cashBack.CashBackRepository;
import it.quofind.application.company.Company;
import it.quofind.application.company.CompanyRepository;
import it.quofind.application.errors.ElementAlreadyPresentException;
import it.quofind.application.errors.NotFoundException;
import lombok.extern.slf4j.Slf4j;
@Service
@Slf4j
public class UserServiceMio {

	@Autowired
	UserRepository ur;
	@Autowired
	RoleRepository rp;	
	@Autowired
	CompanyRepository companyRepository;
	
	@Autowired
	ProfileRepository profileRepository;
	




	/**
	 * inserimento di uno user con possibilita di scelta sul ruolo
	 * @param user
	 * @throws ElementAlreadyPresentException
	 * @throws NotFoundException
	 */
	public void inserisciUtente(InserisciUserRequestDto2 user) throws ElementAlreadyPresentException, NotFoundException{
		log.info("siamo nell'inserisci nell'inseri user");
		User user2 = new User();
		if(!ur.existsByUsername(user.getUsername())) {
			BeanUtils.copyProperties(user, user2);
				if(user.getUserType().equalsIgnoreCase("ADMIN") ) {
					user2.setUserType(UserTypeEnum.ADMIN);
				}
				else if(user.getUserType().equalsIgnoreCase("BUYER")) {
					user2.setUserType(UserTypeEnum.BUYER);
				}
				else if(user.getUserType().equalsIgnoreCase("COLLABORATOR")) {
					user2.setUserType(UserTypeEnum.COLLABORATOR);
				}
				else if(user.getUserType().equalsIgnoreCase("SELLER")) {
					user2.setUserType(UserTypeEnum.SELLER);
				}
				else {
					throw new NotFoundException("user type not found");
				}
			
			Company company = companyRepository.findById(user.getCompanyId()).orElseThrow(()-> new NotFoundException("company non trovata"));
			user2.setCompany(company);
			company.getUsers().add(user2);
			user2.setPassword(BCrypt.hashpw(user2.getPassword(),BCrypt.gensalt()));
			String elencoRuoli = user.getRoles();
			if(elencoRuoli.isBlank()) {
				elencoRuoli= "ROLE_USER";
			}
			String[]listaRuoli=elencoRuoli.split(",");
			Set <Role> ruoli = new HashSet<Role>();
			log.info(elencoRuoli);
			for(int i=0; i<listaRuoli.length; i++) {
				Role r = rp.findByRoleNameString(listaRuoli[i]);
				if(r != null) {
					log.info(r.getRoleName().toString());
					ruoli.add(r);
				}
				else {
					throw new NotFoundException("ruolo inesistente");
				}
			}
			user2.setRoles(ruoli);
			ur.save(user2);
		}
		else {
			throw new ElementAlreadyPresentException("user gia esistente nel db");
		}
	}


	/**
	 * inserimento di un admin
	 * @param user
	 * @throws ElementAlreadyPresentException
	 * @throws NotFoundException 
	 */
	

	/**
	 * modifica di uno user
	 * @param user
	 * @throws NotFoundException
	 * @throws ElementAlreadyPresentException 
	 */
	public void modificaUser(String username,ModificaUserRequestDTO user) throws NotFoundException, ElementAlreadyPresentException  {
		log.info("siamo nel modifica user");
		if(ur.existsByUsername(username)) {
			User user2 = ur.findByUsername(username).get();
			BeanUtils.copyProperties(user, user2);
			Profile profile = profileRepository.findById(user.getProfileId()).orElseThrow(()-> new NotFoundException("profile non trovato"));
			user2.setProfile(profile);
			
			Company company = companyRepository.findById(user.getCompanyId()).orElseThrow(()-> new NotFoundException("company non trovata"));
			user2.setCompany(company);
			company.getUsers().add(user2);
			user2.setPassword(BCrypt.hashpw(user2.getPassword(),BCrypt.gensalt()));
			String elencoRuoli = user.getRoles();
			if(elencoRuoli.isBlank()) {
				elencoRuoli= "ROLE_USER";
			}
			String[]listaRuoli=elencoRuoli.split(",");
			Set <Role> ruoli = new HashSet<Role>();
			log.info(elencoRuoli);
			for(int i=0; i<listaRuoli.length; i++) {
				Role r = rp.findByRoleNameString(listaRuoli[i]);
				if(r != null) {
					log.info(r.getRoleName().toString());
					ruoli.add(r);
				}
				else {
					throw new NotFoundException("ruolo inesistente");
				}
			}
			user2.setRoles(ruoli);
			ur.save(user2);
		}
		else {
			throw new NotFoundException("user non esistente nel db");
		}
	}

	/**
	 * eliminazione di uno user
	 * @param id
	 * @throws NotFoundException
	 */
	public void eliminaUser(Long id) throws NotFoundException {
		log.info("siamo nell'elimina user");
		if(ur.existsById(id)) {
			ur.deleteById(id);

		}
		else{ throw new NotFoundException("User inesistente");}

	}

	/**
	 * ricerca di tutti gli user presenti nel db
	 * @return
	 */
	public CercaTuttiGliUserResponseDTO trovaTuttiGliUser() {
		log.info("siamo nel trova modifica user");
		CercaTuttiGliUserResponseDTO dto = new CercaTuttiGliUserResponseDTO ();
		List<User> lu = (List)ur.findAll(); 
		if(lu.size()> 0) {
			dto.setUserTrovati(lu.size());
			dto.setElencoUser(lu);
			return dto;
		}
		return dto;

	}

	/**
	 * disabilitazione di un account
	 * @param dto
	 * @throws NotFoundException
	 */
	public void disabilitaUser(Long id) throws NotFoundException {
		log.info("siamo nel disabilità user");
		if(ur.existsById(id)){
			User u	=ur.findById(id).get();
			ur.save(u);

		}
		else {

			throw new NotFoundException("User inesistente");
		}


	}


	/**
	 * attivazione di un account
	 * @param dto
	 * @throws NotFoundException
	 */
	public void attivaUser(Long id) throws NotFoundException {
		log.info("siamo disabilita user");
		if(ur.existsById(id)){
			User u	=ur.findById(id).get();
			ur.save(u);

		}
		else {

			throw new NotFoundException("User inesistente");
		}
	}


}
