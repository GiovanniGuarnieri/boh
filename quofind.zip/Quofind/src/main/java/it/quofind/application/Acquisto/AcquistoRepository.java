package it.quofind.application.Acquisto;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface AcquistoRepository extends PagingAndSortingRepository<Acquisto, Long> {

}
