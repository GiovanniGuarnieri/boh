package it.quofind.application.trattamentostruttura;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import it.quofind.application.Struttura.InsertStrutturaRequestDTO;
import it.quofind.application.Struttura.Struttura;
import it.quofind.application.errors.NotFoundException;

@RestController
@RequestMapping("TrattamentiStruttura")
public class TrattamentiStrutturaController {
	
	@Autowired
	TrattamentoStrutturaService service;
	
	
	@Operation (summary = "Inserisce un TrattamentiStruttura nel db", description = "inserisce un TrattamentiStruttura nel db ")
	@ApiResponse(responseCode = "200" , description = "TrattamentiStruttura inserito")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated ")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@PostMapping(path = "/inserisci-TrattamentiStruttura" ,produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity<?> inserisciTrattamentiStruttura(@Valid @RequestBody InsertTrattamentoStrutturaRequestDTO dto) throws NotFoundException  {
		service.insertTrattamentiStruttura(dto);
			return ResponseEntity.ok("TrattamentiStruttura inserita");
		}
	@Operation (summary = "modifica un TrattamentiStruttura ", description = "modifica un TrattamentiStruttura ")
	@ApiResponse(responseCode = "200" , description = "modifica avvenuta")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated  ")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/modifica-Struttura/{id}")
	public ResponseEntity<?> modificaTrattamentiStruttura(@Valid @PathVariable Long id, @RequestBody InsertTrattamentoStrutturaRequestDTO dto) throws NotFoundException {
		service.updateTrattamentiStruttura(id, dto);
		return ResponseEntity.ok("Trattamenti Struttura modificato");
	}


	@Operation (summary = "elimina un InsertTrattamentoStrutturaRequestDTO", description = "elimina un InsertTrattamentoStrutturaRequestDTO")
	@ApiResponse(responseCode = "200" , description = "eliminazione Trattamenti Struttura")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated ")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@DeleteMapping("/elimina-Trattamenti Struttura")
	public ResponseEntity<?> eliminaTrattamentiStruttura(@Valid Long id ) throws NotFoundException {
		service.delete(id);
		return ResponseEntity.ok("Trattamenti Struttura eliminato");
	}
	
	@Operation (summary = "ritorna tutti Trattamenti Struttura ", description = "ritorna la lista di Trattamenti Struttura")
	@ApiResponse(responseCode = "200" , description = "lista Trattamenti Struttura")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/get-all")
	public ResponseEntity<Page<Struttura>> tutteTrattamentiStruttura(Pageable page) {
		return ResponseEntity.ok(service.getAll(page));
	}
	
	@Operation (summary = "ritorna un Trattamenti Struttura ", description = "ritorna un Trattamenti Struttura ")
	@ApiResponse(responseCode = "200" , description = "Trattamenti Struttura")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/get-byid/{id}")
	public ResponseEntity<TrattamentiStruttura> tuttiTrattamentiStrutturabyID(@Valid @PathVariable Long id) throws NotFoundException {
		return ResponseEntity.ok(service.getById(id));
	}
}
