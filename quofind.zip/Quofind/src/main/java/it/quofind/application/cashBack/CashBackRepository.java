package it.quofind.application.cashBack;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface CashBackRepository extends PagingAndSortingRepository<CashBack, Long> {

}
