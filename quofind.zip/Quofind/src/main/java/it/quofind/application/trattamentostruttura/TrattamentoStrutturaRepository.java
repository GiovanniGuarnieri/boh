package it.quofind.application.trattamentostruttura;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface TrattamentoStrutturaRepository extends PagingAndSortingRepository<TrattamentiStruttura, Long> {

}
