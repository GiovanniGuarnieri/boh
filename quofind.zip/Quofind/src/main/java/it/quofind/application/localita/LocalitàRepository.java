package it.quofind.application.localita;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface LocalitàRepository extends PagingAndSortingRepository<Localita, Long> {

}
