package it.quofind.application.trattamentostruttura;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.quofind.application.Struttura.Struttura;
import it.quofind.application.Struttura.StrutturaRepository;
import it.quofind.application.errors.NotFoundException;
import it.quofind.application.trattamento.Trattamento;
import it.quofind.application.trattamento.TrattamentoRepository;

@Service
public class TrattamentoStrutturaService {
	
	@Autowired
	TrattamentoStrutturaRepository trattamentoStrutturaRepository;
	
	@Autowired
	StrutturaRepository strutturaRepository;
	
	@Autowired
	TrattamentoRepository trattamentoRepository;
	
	
	
	
	public Page getAll(Pageable page) {
		return trattamentoStrutturaRepository.findAll(page);
		
	}
	
	
	public TrattamentiStruttura getById(Long id) throws NotFoundException {
		return trattamentoStrutturaRepository.findById(id).orElseThrow(()-> new NotFoundException("trattamenti struttura non trovati"));
	}
	
	public boolean delete(Long id) throws NotFoundException {
		if(trattamentoStrutturaRepository.existsById(id)) {
			trattamentoStrutturaRepository.deleteById(id);
			return true;
		}
		throw new NotFoundException("trattamenti Struttura non trovati");
	}

	
	public void insertTrattamentiStruttura(InsertTrattamentoStrutturaRequestDTO dto) throws NotFoundException {
		TrattamentiStruttura trattamentiStruttura = new TrattamentiStruttura();
		Struttura struttura = strutturaRepository.findById(dto.getStrutturaId()).orElseThrow(()-> new NotFoundException("struttura non trovata"));
		Trattamento trattamento = trattamentoRepository.findById(dto.getTrattamentoId()).orElseThrow(()-> new NotFoundException("trattamento non trovato"));
		trattamentoStrutturaRepository.save(trattamentiStruttura);
	}
	
	
	public void updateTrattamentiStruttura(Long id,InsertTrattamentoStrutturaRequestDTO dto) throws NotFoundException {
		TrattamentiStruttura trattamentiStruttura = trattamentoStrutturaRepository.findById(id).orElseThrow(()-> new NotFoundException("trattamento struttura non trovato"));
		Struttura struttura = strutturaRepository.findById(dto.getStrutturaId()).orElseThrow(()-> new NotFoundException("struttura non trovata"));
		Trattamento trattamento = trattamentoRepository.findById(dto.getTrattamentoId()).orElseThrow(()-> new NotFoundException("trattamento non trovato"));
		trattamentoStrutturaRepository.save(trattamentiStruttura);
	}
}
