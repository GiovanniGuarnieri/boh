package it.quofind.application.trattamento;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface TrattamentoRepository extends PagingAndSortingRepository<Trattamento, Long> {

}
