package it.quofind.application.trattamento;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import it.quofind.application.Struttura.Struttura;
import it.quofind.application.company.Company;
import it.quofind.application.localita.Localita;
import it.quofind.application.trattamentostruttura.TrattamentiStruttura;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "trattamento")
public class Trattamento {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String descrizione;
	@OneToMany(mappedBy = "trattamento")
	private List<TrattamentiStruttura> trattamentiStruttura;

}
