package it.quofind.application.Acquisto;

import java.time.LocalDateTime;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



@Data
@NoArgsConstructor
@AllArgsConstructor
public class InsertAcquistoRequestDTO {
	static final String DATETIME_PATTERN ="dd/MM/yyyy HH:mm:ss";
	@NotBlank(message = "il campo descrizione è obbligatorio")
	private String Descrizione;
	@NotNull(message = "il campo prezzo è obbligatorio")
	private Double prezzo;
	@NotNull(message = "il campo comapny_id è obbligatorio")
	@JsonProperty(value = "company_id")
	private Long companyId;
	@JsonProperty(value = "cashBack_id")
	private Long cashBackId;
	@JsonFormat(pattern = DATETIME_PATTERN)
	private LocalDateTime dataAcquisto;
	
	

	
}
