package it.quofind.application.acquisto;

import static org.assertj.core.api.Assertions.assertThat;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import it.quofind.application.Acquisto.Acquisto;
import it.quofind.application.Acquisto.AcquistoRepository;
import it.quofind.application.Acquisto.AcquistoService;
import it.quofind.application.Acquisto.InsertAcquistoRequestDTO;
import it.quofind.application.company.Company;
import it.quofind.application.company.CompanyRepository;

import it.quofind.application.errors.ElementAlreadyPresentException;
import it.quofind.application.errors.NotFoundException;


@SpringBootTest
public class AcquistoServiceTest {
	
	@Autowired
	AcquistoService acquistoService;
	@Autowired
	AcquistoRepository acquistoRepository;
	@Autowired
	CompanyRepository companyRepository;
	Pageable pageable = Pageable.ofSize(20);
	

	@Order(1)
	@Test
	@Transactional
	public void  insertAcquisto() throws ElementAlreadyPresentException, NotFoundException {
		InsertAcquistoRequestDTO dto = new InsertAcquistoRequestDTO();
		Company company = new Company();
		Company companySaved = companyRepository.save(company);
		dto.setCompanyId(companySaved.getId());
	  	acquistoService.insertAcquisto(dto);
		Page<Acquisto> acquisto = acquistoRepository.findAll(pageable);
		assertThat(acquisto.getNumberOfElements()).isEqualTo(1);
	}
	
	@Order(2)
	@Test
	@Transactional
	public void getAll() throws ElementAlreadyPresentException, NotFoundException {
		InsertAcquistoRequestDTO dto = new InsertAcquistoRequestDTO();
		Company company = new Company();
		Company companySaved = companyRepository.save(company);
		dto.setCompanyId(companySaved.getId());
	  	acquistoService.insertAcquisto(dto);
	  	InsertAcquistoRequestDTO dto2 = new InsertAcquistoRequestDTO();
		Company company2 = new Company();
		Company companySaved2 = companyRepository.save(company);
		dto.setCompanyId(companySaved.getId());
	  	acquistoService.insertAcquisto(dto);
		Page companies = acquistoService.findAll(pageable);
		assertThat(companies.getNumberOfElements()).isEqualTo(2);
	}
	@Order(3)
	@Test
	@Transactional
	public void getByid() throws NotFoundException {
		Acquisto acquisto = new Acquisto();
		Company company = new Company();
		Company companySaved = companyRepository.save(company);
		acquisto.setCompany(companySaved);
		Acquisto acquistoSaved =	acquistoRepository.save(acquisto);
		Acquisto acquistoGet = acquistoService.findById(acquistoSaved.getId());
		boolean result = acquistoGet !=null;
		assertThat(result).isEqualTo(true);
	}

	@Order(4)
	@Test
	@Transactional
	public void UpdateAcquisto() throws NotFoundException {
		InsertAcquistoRequestDTO dto = new InsertAcquistoRequestDTO();
		Company company = new Company();
		Company companySaved = companyRepository.save(company);
		dto.setCompanyId(companySaved.getId());
		dto.setDescrizione("ciao");
		Acquisto acquisto = new Acquisto();
		acquisto.setCompany(companySaved);
		company.getAcquisti().add(acquisto);
		Acquisto acquistoSaved = acquistoRepository.save(acquisto);
		acquistoService.updateAcquisto(acquistoSaved.getId(), dto);
		assertThat(acquistoSaved.getDescrizione()).isEqualTo("ciao");

	}
	@Order(5)
	@Test
	@Transactional
	public void delete() throws ElementAlreadyPresentException, NotFoundException {
		Acquisto acquisto = new Acquisto();
		Acquisto acquistoSaved =	acquistoRepository.save(acquisto);
		Page acquisti= acquistoService.findAll(pageable);
		assertThat(acquisti.getNumberOfElements()).isEqualTo(1);
		acquistoService.delete(acquistoSaved.getId());
		Page acquistiAfterDelete = acquistoService.findAll(pageable);
		assertThat(acquistiAfterDelete.getNumberOfElements()).isEqualTo(0);
	}

}
