package it.quofind.application.trattamentiStruttura;

import static org.assertj.core.api.Assertions.assertThat;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import it.quofind.application.Acquisto.Acquisto;
import it.quofind.application.Struttura.Struttura;
import it.quofind.application.Struttura.StrutturaRepository;
import it.quofind.application.cashback.CashBack;
import it.quofind.application.cashback.InsertCashBackRequestDTO;
import it.quofind.application.errors.NotFoundException;
import it.quofind.application.trattamentistruttura.InsertTrattamentiStrutturaRequestDTO;
import it.quofind.application.trattamentistruttura.TrattamentiStruttura;
import it.quofind.application.trattamentistruttura.TrattamentiStrutturaRepository;
import it.quofind.application.trattamentistruttura.TrattamentiStrutturaService;
import it.quofind.application.trattamento.Trattamento;
import it.quofind.application.trattamento.TrattamentoRepository;
import it.quofind.application.user.User;

@SpringBootTest
public class TrattamentiStrutturaServiceTest {


	@Autowired
	TrattamentiStrutturaRepository trattamentoStrutturaRepository;

	@Autowired
	StrutturaRepository strutturaRepository;

	@Autowired
	TrattamentoRepository trattamentoRepository;

	@Autowired
	TrattamentiStrutturaService trattamentiStrutturaService;




	Pageable pageable = Pageable.ofSize(20);

	@Order(1)
	@Test
	@Transactional
	public void  insertTrattamentiStruttura() throws  NotFoundException {
		InsertTrattamentiStrutturaRequestDTO dto = new InsertTrattamentiStrutturaRequestDTO();
		Struttura struttura = new Struttura();
		Struttura strutturaSaved=strutturaRepository.save(struttura);
		Trattamento trattamento = new Trattamento();
		Trattamento trattamentoSaved= trattamentoRepository.save(trattamento);
		dto.setStrutturaId(strutturaSaved.getId());
		dto.setTrattamentoId(trattamentoSaved.getId());
		trattamentiStrutturaService.insertTrattamentiStruttura(dto);
		Page<TrattamentiStruttura> list = trattamentiStrutturaService.getAll(pageable);
		assertThat(list.getNumberOfElements()).isEqualTo(1);

	}

	@Order(2)
	@Test
	@Transactional
	public void getAll() throws NotFoundException {
		InsertTrattamentiStrutturaRequestDTO dto = new InsertTrattamentiStrutturaRequestDTO();
		Struttura struttura = new Struttura();
		Struttura strutturaSaved=strutturaRepository.save(struttura);
		Trattamento trattamento = new Trattamento();
		Trattamento trattamentoSaved= trattamentoRepository.save(trattamento);
		dto.setStrutturaId(strutturaSaved.getId());
		dto.setTrattamentoId(trattamentoSaved.getId());
		trattamentiStrutturaService.insertTrattamentiStruttura(dto);
		Page<TrattamentiStruttura> list = trattamentiStrutturaService.getAll(pageable);
		assertThat(list.getNumberOfElements()).isEqualTo(1);

	}
	@Order(3)
	@Test
	@Transactional
	public void getByid() throws NotFoundException {
		TrattamentiStruttura trattamentiStruttura = new TrattamentiStruttura();
		Struttura struttura = new Struttura();
		Struttura strutturaSaved=strutturaRepository.save(struttura);
		Trattamento trattamento = new Trattamento();
		Trattamento trattamentoSaved= trattamentoRepository.save(trattamento);
		trattamentiStruttura.setStruttura(strutturaSaved);
		trattamentiStruttura.setTrattamento(trattamentoSaved);
		TrattamentiStruttura trattamentiStrutturaSaved =trattamentoStrutturaRepository.save(trattamentiStruttura);
		TrattamentiStruttura trattamentiStrutturaGet = trattamentiStrutturaService.getById(trattamentiStrutturaSaved.getId());
		boolean result = trattamentiStrutturaGet !=null;
		assertThat(result).isEqualTo(true);

	}

	@Order(4)
	@Test
	@Transactional
	public void UpdateTrattamentiStruttura() throws NotFoundException {
		InsertTrattamentiStrutturaRequestDTO dto = new InsertTrattamentiStrutturaRequestDTO();
		TrattamentiStruttura trattamentiStruttura = new TrattamentiStruttura();
		TrattamentiStruttura trattamentiStrutturaSaved = trattamentoStrutturaRepository.save(trattamentiStruttura);
		Struttura struttura = new Struttura();
		Struttura strutturaSaved=strutturaRepository.save(struttura);
		Trattamento trattamento = new Trattamento();
		Trattamento trattamentoSaved= trattamentoRepository.save(trattamento);
		dto.setStrutturaId(strutturaSaved.getId());
		dto.setTrattamentoId(trattamentoSaved.getId());
		trattamentiStrutturaService.updateTrattamentiStruttura(trattamentiStrutturaSaved.getId(), dto);
		assertThat(trattamentiStrutturaSaved.getId().equals(trattamentoSaved.getId()));

	}
	@Order(5)
	@Test
	@Transactional
	public void delete() throws  NotFoundException {
		TrattamentiStruttura trattamentiStruttura = new TrattamentiStruttura();
		Struttura struttura = new Struttura();
		Struttura strutturaSaved=strutturaRepository.save(struttura);
		Trattamento trattamento = new Trattamento();
		Trattamento trattamentoSaved= trattamentoRepository.save(trattamento);
		trattamentiStruttura.setStruttura(strutturaSaved);
		trattamentiStruttura.setTrattamento(trattamentoSaved);
		TrattamentiStruttura trattamentiStrutturaSaved = trattamentoStrutturaRepository.save(trattamentiStruttura);
		Page<TrattamentiStruttura> list = trattamentiStrutturaService.getAll(pageable);
		assertThat(list.getNumberOfElements()).isEqualTo(1);
		trattamentiStrutturaService.delete(trattamentiStrutturaSaved.getId());
		Page listAfterDelete = trattamentiStrutturaService.getAll(pageable);
		assertThat(listAfterDelete.getNumberOfElements()).isEqualTo(0);
	}



}
