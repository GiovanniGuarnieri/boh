package it.quofind.application.company;

import static org.assertj.core.api.Assertions.assertThat;

import javax.annotation.security.RunAs;
import javax.transaction.Transactional;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit4.SpringRunner;

import it.quofind.application.company.Company;
import it.quofind.application.company.CompanyRepository;
import it.quofind.application.company.CompanyService;
import it.quofind.application.company.InsertCompanyRequestDTO;
import it.quofind.application.errors.ElementAlreadyPresentException;
import it.quofind.application.errors.NotFoundException;
import it.quofind.application.user.User;
import it.quofind.application.user.UserRepository;


@SpringBootTest
public class CompanyServiceTest {
	@Autowired
	CompanyRepository companyRepository;
	@Autowired
	UserRepository userRepository;
	@Autowired
	CompanyService companyService;

	Pageable pageable = Pageable.ofSize(20);



	@Order(1)
	@Test
	@Transactional
	public void  insertCompany() throws ElementAlreadyPresentException {
		InsertCompanyRequestDTO dto = new InsertCompanyRequestDTO();
		dto.setCompanyName("company");
		companyService.insertCompany(dto);
		Page<Company> companies = companyRepository.findAll(pageable);
		assertThat(companies.getNumberOfElements()).isEqualTo(1);
	}
	
	@Order(2)
	@Test
	@Transactional
	public void getAll() throws ElementAlreadyPresentException {
		InsertCompanyRequestDTO dto = new InsertCompanyRequestDTO();
		dto.setCompanyName("company");
		companyService.insertCompany(dto);
		
		InsertCompanyRequestDTO dto2 = new InsertCompanyRequestDTO();
		dto.setCompanyName("company5");
		companyService.insertCompany(dto);
		Page companies = companyService.findAll(pageable);
		assertThat(companies.getNumberOfElements()).isEqualTo(2);
	}
	@Order(3)
	@Test
	@Transactional
	public void getByUser() throws NotFoundException, ElementAlreadyPresentException {
		Company company = new Company();
		companyRepository.save(company);
		User user = new User();
		user.setUsername("ciao");
		user.setCompany(company);
		company.getUsers().add(user);
		userRepository.save(user);
		company = companyService.findCompanyByUser(user.getUsername());
		boolean result = company !=null;
		assertThat(result).isEqualTo(true);
	}

	@Order(4)
	@Test
	@Transactional
	public void UpdateCompany() throws NotFoundException {
		Company company = new Company();
		Company companySaved = companyRepository.save(company);
		InsertCompanyRequestDTO dto = new InsertCompanyRequestDTO();
		dto.setCompanyName("companyUpdate");
		companyService.UpdateCompany(companySaved.getId(), dto);
		assertThat(companySaved.getCompanyName()).isEqualTo("companyUpdate");

	}
	@Order(5)
	@Test
	@Transactional
	public void deleteCompany() throws ElementAlreadyPresentException, NotFoundException {
		Company company = new Company();
		Company companySaved = companyRepository.save(company);
		Page companies = companyService.findAll(pageable);
		assertThat(companies.getNumberOfElements()).isEqualTo(1);
		companyService.deleteById(companySaved.getId());
		Page companiesAfterDelete = companyService.findAll(pageable);
		assertThat(companiesAfterDelete.getNumberOfElements()).isEqualTo(0);
	}


}
