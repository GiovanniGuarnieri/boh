package it.quofind.application.Struttura;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface StrutturaRepository extends PagingAndSortingRepository<Struttura, Long> {

}
