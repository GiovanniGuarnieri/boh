package it.quofind.application.trattamento;

import javax.validation.constraints.NotBlank;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class InsertTrattamentoRequestDTO {
	@NotBlank(message = "il campo descrizione non può essere null")
	private String descrizione;
	
}
