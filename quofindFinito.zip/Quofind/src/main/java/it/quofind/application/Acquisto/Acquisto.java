package it.quofind.application.Acquisto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import it.quofind.application.cashback.CashBack;
import it.quofind.application.company.Company;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "Acquisto")
public class Acquisto {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String Descrizione;
	private Double prezzo;
	@JoinColumn(name = "company_id")
	@ManyToOne
	private Company company;
	@JsonIgnoreProperties({"acquisto"})
	@OneToMany(mappedBy = "acquisto")
	private List<CashBack> cashBack = new ArrayList<CashBack>();
	private LocalDateTime dataAcquisto;


}
