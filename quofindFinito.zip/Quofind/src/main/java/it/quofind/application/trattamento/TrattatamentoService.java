package it.quofind.application.trattamento;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.quofind.application.errors.NotFoundException;

@Service
public class TrattatamentoService {
	
	@Autowired
	TrattamentoRepository trattamentoRepository;
	
	
	public Page getAll(Pageable Page) {
		return trattamentoRepository.findAll(Page);
		}
	
	public Trattamento getById(Long id) throws NotFoundException {
		return trattamentoRepository.findById(id).orElseThrow(()-> new NotFoundException("trattamento non trovato"));
	}
	
	public boolean delete(Long id) throws NotFoundException {
		if(trattamentoRepository.existsById(id)) {
			trattamentoRepository.deleteById(id);
			return true;
		}
		throw new NotFoundException("trattamento non trovato");
	}
	
	public void insertTrattamento(InsertTrattamentoRequestDTO dto) {
		Trattamento trattamento = new Trattamento();
		BeanUtils.copyProperties(dto, trattamento);
		trattamentoRepository.save(trattamento);
		
	}
	
	public void updateTrattamento(Long id,InsertTrattamentoRequestDTO dto) throws NotFoundException {
		Trattamento trattamento = trattamentoRepository.findById(id).orElseThrow(()-> new NotFoundException("trattamento non trovato"));
		BeanUtils.copyProperties(dto, trattamento);
		trattamentoRepository.save(trattamento);
	}

}
