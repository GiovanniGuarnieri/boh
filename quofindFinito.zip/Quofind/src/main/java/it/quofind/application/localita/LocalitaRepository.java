package it.quofind.application.localita;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface LocalitaRepository extends PagingAndSortingRepository<Localita, Long> {

}
