package it.quofind.application.cashback;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface CashBackRepository extends PagingAndSortingRepository<CashBack, Long> {

}
