package it.quofind.application.trattamentistruttura;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface TrattamentiStrutturaRepository extends PagingAndSortingRepository<TrattamentiStruttura, Long> {

}
