package it.quofind.application.Struttura;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.quofind.application.company.Company;
import it.quofind.application.company.CompanyRepository;
import it.quofind.application.errors.NotFoundException;
import it.quofind.application.localita.Localita;
import it.quofind.application.localita.LocalitaRepository;



@Service
public class StrutturaService {
	
	@Autowired
	StrutturaRepository strutturaRepository;
	@Autowired
	LocalitaRepository localitaRepository;
	@Autowired
	CompanyRepository companyRepository;
	
	
	
	
	public Page getAll(Pageable page) {
		return strutturaRepository.findAll(page);
	}
	
	public Struttura getById(Long id) throws NotFoundException {
		return strutturaRepository.findById(id).orElseThrow(()-> new NotFoundException("struttura non trovata"));
	}

	public boolean delete(Long id) throws NotFoundException {
		if(strutturaRepository.existsById(id)) {
			strutturaRepository.deleteById(id);
			return true;
		}
		throw new NotFoundException("Struttura non trovata");
	}
	@Transactional
	public void insertStruttura(InsertStrutturaRequestDTO dto) throws NotFoundException {
		Struttura struttura = new Struttura();
		BeanUtils.copyProperties(dto, struttura);
		Company company = companyRepository.findById(dto.getIdCompany()).orElseThrow(()-> new NotFoundException("company non trovat"));
		Localita localita = localitaRepository.findById(dto.getIdLocalita()).orElseThrow(()->new NotFoundException("località non trovata"));
		struttura.setCompany(company);
		company.getStrutture().add(struttura);
		struttura.setLocalita(localita);
		localita.getStrutture().add(struttura);
		strutturaRepository.save(struttura);
		
		
	}
	
	@Transactional
	public void updateStruttura(Long id,InsertStrutturaRequestDTO dto) throws NotFoundException {
		Struttura struttura = strutturaRepository.findById(id).orElseThrow(()-> new NotFoundException("struttura non trovata"));
		BeanUtils.copyProperties(dto, struttura);
		Company company = companyRepository.findById(dto.getIdCompany()).orElseThrow(()-> new NotFoundException("company non trovat"));
		Localita localita = localitaRepository.findById(dto.getIdLocalita()).orElseThrow(()->new NotFoundException("località non trovata"));
		struttura.setCompany(company);
		company.getStrutture().add(struttura);
		struttura.setLocalita(localita);
		localita.getStrutture().add(struttura);
		strutturaRepository.save(struttura);
	}
	
}
