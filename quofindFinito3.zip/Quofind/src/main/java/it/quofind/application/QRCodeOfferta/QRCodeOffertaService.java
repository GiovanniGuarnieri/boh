package it.quofind.application.QRCodeOfferta;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.quofind.application.errors.NotFoundException;
import it.quofind.application.offerte.Offerta;
import it.quofind.application.offerte.OffertaRepository;

@Service
public class QRCodeOffertaService {


	@Autowired
	OffertaRepository offertaRepo;
	@Autowired
	QRCodeOffertaRepository qrRepository;



	public void insert(InsertQrRequestDTO dto) throws NotFoundException {
		QRCodeOfferta codeOfferta = new QRCodeOfferta();
		BeanUtils.copyProperties(dto, codeOfferta);
		Offerta offerta =	offertaRepo.findById(dto.getOffertaId()).orElseThrow(()-> new NotFoundException("offerta non trovata"));
		codeOfferta.setOfferta(offerta);
		offerta.getQRCodeOfferte().add(codeOfferta);
		qrRepository.save(codeOfferta);
	}
	
	
	public void update(Long id , InsertQrRequestDTO dto) throws NotFoundException {
	QRCodeOfferta codeOfferta =	qrRepository.findById(id).orElseThrow(()->new NotFoundException("QRCodeOfferta non trovata"));
	Offerta offerta = offertaRepo.findById(dto.getOffertaId()).orElseThrow(()-> new NotFoundException("offerta"));
	BeanUtils.copyProperties(codeOfferta, offerta);
	codeOfferta.setOfferta(offerta);
	offerta.getQRCodeOfferte().add(codeOfferta);
	qrRepository.save(codeOfferta);
	}
	
	
	public QRCodeOfferta getId(Long id ) throws NotFoundException {
	return qrRepository.findById(id).orElseThrow(()-> new NotFoundException("QRCodeOfferta"));
	}
	
	
	public Page getAll(Pageable pageable) {
	return qrRepository.findAll(pageable);
	}
	
	public Boolean delete(Long id) throws NotFoundException {
		if(qrRepository.existsById(id)) {
			qrRepository.deleteById(id);
			return true;
		}
		throw new NotFoundException("QRCodeOfferta non trovato");
	}
	
	

}
