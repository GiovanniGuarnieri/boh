package it.quofind.application.user;

import lombok.experimental.FieldNameConstants;

public enum UserTypeEnum {
	
	@FieldNameConstants.Include COLLABORATOR,
	@FieldNameConstants.Include SELLER,
	@FieldNameConstants.Include ADMIN,
	@FieldNameConstants.Include BUYER,

}
