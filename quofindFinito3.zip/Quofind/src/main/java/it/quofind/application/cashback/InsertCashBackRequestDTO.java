package it.quofind.application.cashback;

import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class InsertCashBackRequestDTO {
	@NotNull(message = "il campo userid non puo essere")
	private String userId;
	@NotNull(message = "il campo acquisto non puo essere")
	private Long acquistoId;
	
	@NotNull(message = "il campo totale non può essere null")
	private double totale;
	@NotNull(message = "il campo percentuale non può essere null")
	private double percentuale;
	@NotNull(message = "il campo cashback non può essere null")
	private double cashBack;


	
	

}
