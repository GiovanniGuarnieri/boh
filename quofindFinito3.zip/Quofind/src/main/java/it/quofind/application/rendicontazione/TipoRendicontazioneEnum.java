package it.quofind.application.rendicontazione;

public enum TipoRendicontazioneEnum {

	
	FIDELIZZAZIONE,
	LEADER,
	RECENSIONE,
	COMMISSIONE
	
}
