package it.quofind.application.company;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import it.quofind.application.Struttura.Struttura;
import it.quofind.application.acquisto.Acquisto;
import it.quofind.application.user.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="companies")
public class Company {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column(nullable = true, length = 100)
	private String companyName;
	@Enumerated(EnumType.STRING)
	private CompanyTypesEnum companyType;
	@EqualsAndHashCode.Exclude
	@OneToMany(mappedBy = "company")
	private List<Acquisto>acquisti = new ArrayList<Acquisto>();
	@OneToMany(mappedBy = "company", fetch = FetchType.EAGER)
	@JsonIgnoreProperties({"company"})
	private List<User> users=new ArrayList<User>();

	@OneToMany(mappedBy = "company")
	private List<Struttura>strutture = new ArrayList<Struttura>();
	
}
