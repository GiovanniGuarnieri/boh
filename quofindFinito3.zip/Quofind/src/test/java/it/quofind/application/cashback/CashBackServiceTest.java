package it.quofind.application.cashback;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.CALLS_REAL_METHODS;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import it.quofind.application.acquisto.Acquisto;
import it.quofind.application.acquisto.AcquistoRepository;
import it.quofind.application.acquisto.InsertAcquistoRequestDTO;
import it.quofind.application.company.Company;
import it.quofind.application.company.InsertCompanyRequestDTO;
import it.quofind.application.errors.ElementAlreadyPresentException;
import it.quofind.application.errors.NotFoundException;
import it.quofind.application.user.User;
import it.quofind.application.user.UserRepository;

@SpringBootTest
public class CashBackServiceTest {


	@Autowired
	CashBackRepository cashBackRepository;
	@Autowired
	AcquistoRepository acquistoRepository;
	@Autowired
	UserRepository userRepository;

	@Autowired
	CashBackService cashBackService;

	Pageable pageable = Pageable.ofSize(20);

	@Order(1)
	@Test
	@Transactional
	public void  insertCashBack() throws  NotFoundException {
		InsertCashBackRequestDTO dto = new InsertCashBackRequestDTO();
		User user = new User();
		user.setUsername("ciccio");
		User userSaved	=userRepository.save(user);
		Acquisto acquisto = new Acquisto();
		Acquisto acquistoSaved = acquistoRepository.save(acquisto);
		dto.setAcquistoId(acquistoSaved.getId());
		dto.setUserId(userSaved.getUsername());
		cashBackService.insertCashBack(dto);
		Page<CashBack> cashBacks = cashBackRepository.findAll(pageable);
		assertThat(cashBacks.getNumberOfElements()).isEqualTo(1);
		
	}

	@Order(2)
	@Test
	@Transactional
	public void getAll() throws NotFoundException {
		InsertCashBackRequestDTO dto = new InsertCashBackRequestDTO();
		User user = new User();
		user.setUsername("ciccio");
		User userSaved	=userRepository.save(user);
		Acquisto acquisto = new Acquisto();
		Acquisto acquistoSaved = acquistoRepository.save(acquisto);
		dto.setAcquistoId(acquistoSaved.getId());
		dto.setUserId(userSaved.getUsername());
		cashBackService.insertCashBack(dto);
		Page<CashBack> cashBacks = cashBackRepository.findAll(pageable);
		assertThat(cashBacks.getNumberOfElements()).isEqualTo(1);
	}
	@Order(3)
	@Test
	@Transactional
	public void getByid() throws NotFoundException {
		CashBack cashBack = new CashBack();
		User user = new User();
		user.setUsername("ciccio");
		User userSaved	=userRepository.save(user);
		Acquisto acquisto = new Acquisto();
		Acquisto acquistoSaved = acquistoRepository.save(acquisto);
		cashBack.setAcquisto(acquistoSaved);
		cashBack.setUser(userSaved);
		CashBack cashBackSaved =cashBackRepository.save(cashBack);
		CashBack cashBackGet = cashBackService.findById(cashBackSaved.getId());
		boolean result = cashBackGet !=null;
		assertThat(result).isEqualTo(true);

	}

	@Order(4)
	@Test
	@Transactional
	public void UpdateCashBack() throws NotFoundException {
		CashBack cashBack = new CashBack();
		CashBack cashBackSaved = cashBackRepository.save(cashBack);
		InsertCashBackRequestDTO dto = new InsertCashBackRequestDTO();
		dto.setTotale(50);
		User user = new User();
		user.setUsername("ciccio");
		User userSaved	=userRepository.save(user);
		Acquisto acquisto = new Acquisto();
		Acquisto acquistoSaved = acquistoRepository.save(acquisto);
		dto.setAcquistoId(acquistoSaved.getId());
		dto.setUserId(userSaved.getUsername());
		cashBackService.UpdateCashBack(cashBackSaved.getId(), dto);
		assertThat(cashBackSaved.getTotale() == 50);

	}
	@Order(5)
	@Test
	@Transactional
	public void deleteCashBack() throws  NotFoundException {
		CashBack cashBack = new CashBack();
		User user = new User();
		user.setUsername("ciccio");
		User userSaved	=userRepository.save(user);
		Acquisto acquisto = new Acquisto();
		Acquisto acquistoSaved = acquistoRepository.save(acquisto);
		cashBack.setAcquisto(acquistoSaved);
		cashBack.setUser(userSaved);
		CashBack cashBackSaved = cashBackRepository.save(cashBack);
		Page cashBacks= cashBackService.findall(pageable);
		assertThat(cashBacks.getNumberOfElements()).isEqualTo(1);
		cashBackService.delete(acquistoSaved.getId());
		Page cashBackAfterDelete = cashBackService.findall(pageable);
		assertThat(cashBackAfterDelete.getNumberOfElements()).isEqualTo(0);
	}



}
