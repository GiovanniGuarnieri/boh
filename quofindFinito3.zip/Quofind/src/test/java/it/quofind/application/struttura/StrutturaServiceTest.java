package it.quofind.application.struttura;

import static org.assertj.core.api.Assertions.assertThat;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;


import it.quofind.application.Struttura.InsertStrutturaRequestDTO;
import it.quofind.application.Struttura.Struttura;
import it.quofind.application.Struttura.StrutturaRepository;
import it.quofind.application.Struttura.StrutturaService;

import it.quofind.application.company.Company;
import it.quofind.application.company.CompanyRepository;

import it.quofind.application.errors.ElementAlreadyPresentException;
import it.quofind.application.errors.NotFoundException;
import it.quofind.application.localita.Localita;
import it.quofind.application.localita.LocalitaRepository;


@SpringBootTest
public class StrutturaServiceTest {

	@Autowired
	StrutturaRepository strutturaRepository;
	@Autowired
	LocalitaRepository localitaRepository;
	@Autowired
	CompanyRepository companyRepository;
	
	@Autowired
	StrutturaService strutturaService;
	
	

	Pageable pageable = Pageable.ofSize(20);

	@Order(1)
	@Test
	@Transactional
	public void  insertStruttura() throws  NotFoundException {
		InsertStrutturaRequestDTO dto = new InsertStrutturaRequestDTO();
		Localita localita = new Localita();
		Localita localitaSaved =	localitaRepository.save(localita);
		Company company = new Company();
		Company companySaved = companyRepository.save(company);
		dto.setIdCompany(companySaved.getId());
		dto.setIdLocalita(localitaSaved.getId());
		strutturaService.insertStruttura(dto);
		Page<Struttura> strutture = strutturaRepository.findAll(pageable);
		assertThat(strutture.getNumberOfElements()).isEqualTo(1);
	}

	@Order(2)
	@Test
	@Transactional
	public void getAll() throws ElementAlreadyPresentException, NotFoundException {
		InsertStrutturaRequestDTO dto = new InsertStrutturaRequestDTO();
		Localita localita = new Localita();
		Localita localitaSaved =	localitaRepository.save(localita);
		Company company = new Company();
		Company companySaved = companyRepository.save(company);
		dto.setIdCompany(companySaved.getId());
		dto.setIdLocalita(localitaSaved.getId());
		strutturaService.insertStruttura(dto);
		Page<Struttura> strutture = strutturaRepository.findAll(pageable);
		assertThat(strutture.getNumberOfElements()).isEqualTo(1);
	}
	@Order(3)
	@Test
	@Transactional
	public void getByid() throws NotFoundException {
		Struttura struttura = new Struttura();
		Localita localita = new Localita();
		Localita localitaSaved =	localitaRepository.save(localita);
		Company company = new Company();
		Company companySaved = companyRepository.save(company);
		struttura.setCompany(companySaved);
		struttura.setLocalita(localitaSaved);
		Struttura strutturaSaved = strutturaRepository.save(struttura);
		Struttura strutturaGet = strutturaService.getById(strutturaSaved.getId());
		boolean result = strutturaGet !=null;
		assertThat(result).isEqualTo(true);

	}

	@Order(4)
	@Test
	@Transactional
	public void UpdateStruttura() throws NotFoundException {
		InsertStrutturaRequestDTO dto = new InsertStrutturaRequestDTO();
		Struttura struttura = new Struttura();
		Localita localita = new Localita();
		Localita localitaSaved =	localitaRepository.save(localita);
		Company company = new Company();
		Company companySaved = companyRepository.save(company);
		dto.setDescrizione("ciao");
		dto.setIdCompany(companySaved.getId());
		dto.setIdLocalita(localitaSaved.getId());
		Struttura strutturaSaved = strutturaRepository.save(struttura);
		strutturaService.updateStruttura(strutturaSaved.getId(), dto);
		assertThat(strutturaSaved.getDescrizione().equals("ciao"));

	}
	@Order(5)
	@Test
	@Transactional
	public void delete() throws NotFoundException {
		Struttura struttura = new Struttura();
		Localita localita = new Localita();
		Localita localitaSaved = localitaRepository.save(localita);
		Company company = new Company();
		Company companySaved = companyRepository.save(company);
		struttura.setCompany(companySaved);
		struttura.setLocalita(localitaSaved);
		Struttura strutturaSaved = strutturaRepository.save(struttura);
		Page strutturaGet = strutturaService.getAll(pageable);
		assertThat(strutturaGet.getNumberOfElements()).isEqualTo(1);
		strutturaService.delete(strutturaSaved.getId());
		Page strutturaGetAfterDelete = strutturaService.getAll(pageable);
		assertThat(strutturaGetAfterDelete.getNumberOfElements()).isEqualTo(0);
	}

	
	
	
	
}
