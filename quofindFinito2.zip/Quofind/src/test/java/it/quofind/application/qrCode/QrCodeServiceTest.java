package it.quofind.application.qrCode;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import it.quofind.application.QRCodeOfferta.InsertQrRequestDTO;
import it.quofind.application.QRCodeOfferta.QRCodeOfferta;
import it.quofind.application.QRCodeOfferta.QRCodeOffertaRepository;
import it.quofind.application.QRCodeOfferta.QRCodeOffertaService;

import it.quofind.application.errors.ElementAlreadyPresentException;
import it.quofind.application.errors.NotFoundException;
import it.quofind.application.offerte.Offerta;
import it.quofind.application.offerte.OffertaRepository;

@SpringBootTest
public class QrCodeServiceTest {

	@Autowired
	OffertaRepository offertaRepo;
	@Autowired
	QRCodeOffertaRepository qrRepository;
	
	@Autowired
	QRCodeOffertaService service;
	Pageable pageable = Pageable.ofSize(20);

	@Order(1)
	@Test
	@Transactional
	public void  insert() throws  NotFoundException {
		InsertQrRequestDTO dto = new InsertQrRequestDTO();
		Offerta offerta = new Offerta();
		Offerta offertaSaved =offertaRepo.save(offerta);
		dto.setOffertaId(offertaSaved.getId());
		service.insert(dto);
		Page qrCodes = qrRepository.findAll(pageable);
		assertThat(qrCodes.getNumberOfElements()).isEqualTo(1);
	}

	@Order(2)
	@Test
	@Transactional
	public void getAll() throws ElementAlreadyPresentException, NotFoundException {
		InsertQrRequestDTO dto = new InsertQrRequestDTO();
		Offerta offerta = new Offerta();
		Offerta offertaSaved =	offertaRepo.save(offerta);
		dto.setOffertaId(offertaSaved.getId());
		service.insert(dto);
		Page qrCodes = service.getAll(pageable);
		assertThat(qrCodes.getNumberOfElements()).isEqualTo(1);
	}
	@Order(3)
	@Test
	@Transactional
	public void getByid() throws NotFoundException {
		QRCodeOfferta qrCode = new QRCodeOfferta();
		Offerta offerta = new Offerta();
		Offerta offertaSaved =	offertaRepo.save(offerta);
		qrCode.setOfferta(offertaSaved);
		QRCodeOfferta qrCodeSaved = qrRepository.save(qrCode);
		QRCodeOfferta qrCodGet = service.getId(qrCodeSaved.getId());
		boolean result = qrCodGet !=null;
		assertThat(result).isEqualTo(true);

	}

	@Order(4)
	@Test
	@Transactional
	public void UpdateStruttura() throws NotFoundException {
		InsertQrRequestDTO dto = new InsertQrRequestDTO();
		QRCodeOfferta qrCodeOfferta = new QRCodeOfferta();
		Offerta offerta = new Offerta();
		Offerta offertaSaved =offertaRepo.save(offerta);
		dto.setOffertaId(offertaSaved.getId());
		QRCodeOfferta qrCodeOffertaSaved = qrRepository.save(qrCodeOfferta);
		service.update(qrCodeOffertaSaved.getId(), dto);
		assertThat(true);
	}
	@Order(5)
	@Test
	@Transactional
	public void delete() throws NotFoundException {
		QRCodeOfferta qrCodeOfferta = new QRCodeOfferta();
		Offerta offerta = new Offerta();
		Offerta offertaSaved =offertaRepo.save(offerta);
		QRCodeOfferta qrCodeOffertaSaved = qrRepository.save(qrCodeOfferta);
		Page qrCodesGet = service.getAll(pageable);
		assertThat(qrCodesGet.getNumberOfElements()).isEqualTo(1);
		service.delete(qrCodeOffertaSaved.getId());
		Page strutturaGetAfterDelete = service.getAll(pageable);
		assertThat(strutturaGetAfterDelete.getNumberOfElements()).isEqualTo(0);
	}


}
