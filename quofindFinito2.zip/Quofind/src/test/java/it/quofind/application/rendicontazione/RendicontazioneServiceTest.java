package it.quofind.application.rendicontazione;

import static org.assertj.core.api.Assertions.assertThat;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;


import it.quofind.application.errors.ElementAlreadyPresentException;
import it.quofind.application.errors.NotFoundException;
import it.quofind.application.user.User;
import it.quofind.application.user.UserRepository;

@SpringBootTest
public class RendicontazioneServiceTest {
	@Autowired
	RendicontazioneRepository rendicontazioneRepository;
	@Autowired
	UserRepository ur;
	@Autowired
	RendicontazioneService service;
	
	
	Pageable pageable = Pageable.ofSize(20);


	@Order(1)
	@Test
	@Transactional
	public void  insert() throws  NotFoundException, ElementAlreadyPresentException {
		InsertRendicontazioneRequestDTO dto = new InsertRendicontazioneRequestDTO();
		User user = new User();
		user.setUsername("ciccio");
		User userSaved =ur.save(user);
		dto.setUserName(userSaved.getUsername());
		User userCorrelato = new User();
		userCorrelato.setUsername("pippo");
		User userSavedCorrelato =ur.save(userCorrelato);
		dto.setUserCorrelato(userSavedCorrelato.getUsername());
		dto.setTipoRendicontazione("leader");
		dto.setAnno(2002);
		dto.setMese(11);
		service.insert(dto);
		Page qrCodes = rendicontazioneRepository.findAll(pageable);
		assertThat(qrCodes.getNumberOfElements()).isEqualTo(1);
	}

	@Order(2)
	@Test
	@Transactional
	public void getAll() throws ElementAlreadyPresentException, NotFoundException {
		InsertRendicontazioneRequestDTO dto = new InsertRendicontazioneRequestDTO();
		User user = new User();
		user.setUsername("ciccio");
		User userSaved =	ur.save(user);
		dto.setUserName(userSaved.getUsername());
		User userCorrelato = new User();
		userCorrelato.setUsername("pippo");
		User userSavedCorrelato =ur.save(userCorrelato);
		dto.setTipoRendicontazione("leader");
		dto.setUserCorrelato(userSavedCorrelato.getUsername());
		dto.setAnno(2002);
		dto.setMese(11);
		service.insert(dto);
		Page qrCodes = service.getAll(pageable);
		assertThat(qrCodes.getNumberOfElements()).isEqualTo(1);
	}
	@Order(3)
	@Test
	@Transactional
	public void getByid() throws NotFoundException {
		Rendicontazione rendicontazione = new Rendicontazione();
		User user = new User();
		user.setUsername("ciccio");
		User userSaved =	ur.save(user);
		rendicontazione.setUserName(userSaved);
		Rendicontazione rendicontazioneSaved = rendicontazioneRepository.save(rendicontazione);
		Rendicontazione rendicontazioneGet = service.getById(rendicontazioneSaved.getId());
		boolean result = rendicontazioneGet !=null;
		assertThat(result).isEqualTo(true);

	}

	@Order(4)
	@Test
	@Transactional
	public void UpdateStruttura() throws NotFoundException {
		InsertRendicontazioneRequestDTO dto = new InsertRendicontazioneRequestDTO();
		Rendicontazione rendicontazione = new Rendicontazione();
		User ueser = new User();
		ueser.setUsername("ciccio");
		User userSaved =ur.save(ueser);
		dto.setUserName(userSaved.getUsername());
		User userCorrelato = new User();
		userCorrelato.setUsername("pippo");
		User userSavedCorrelato =ur.save(userCorrelato);
		dto.setUserCorrelato(userSavedCorrelato.getUsername());
		dto.setAnno(2002);
		dto.setMese(11);
		dto.setTipoRendicontazione("leader");
		Rendicontazione rendicontazioneSaved = rendicontazioneRepository.save(rendicontazione);
		service.update(rendicontazioneSaved.getId(), dto);
		assertThat(rendicontazioneSaved.getAnno()==2);
	}
	@Order(5)
	@Test
	@Transactional
	public void delete() throws NotFoundException {
		Rendicontazione rendicontazione = new Rendicontazione();
		User ueser = new User();
		ueser.setUsername("ciccio");
		User userSaved =ur.save(ueser);
		User userCorrelato = new User();
		userCorrelato.setUsername("pippo");
		User userSavedCorrelato =ur.save(userCorrelato);
		rendicontazione.setUserCorrelato(userSavedCorrelato);
		rendicontazione.setAnno(2);
		Rendicontazione rendicontazioneSaved = rendicontazioneRepository.save(rendicontazione);
		Page rendicontazioneGet = service.getAll(pageable);
		assertThat(rendicontazioneGet.getNumberOfElements()).isEqualTo(1);
		service.delete(rendicontazioneSaved.getId());
		Page strutturaGetAfterDelete = service.getAll(pageable);
		assertThat(strutturaGetAfterDelete.getNumberOfElements()).isEqualTo(0);
	}


	
	
	
	
	
	
	
}
