package it.quofind.application.company;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.quofind.application.errors.ElementAlreadyPresentException;
import it.quofind.application.errors.NotFoundException;
import it.quofind.application.user.UserRepository;

@Service
public class CompanyService {
	
	
	@Autowired
	CompanyRepository companyRepository;
	@Autowired
	UserRepository userRepository;
	
	public Page findAll(Pageable page) {
		return companyRepository.findAll(page);
	}
	
	public  Company findCompanyByUser(String Username) throws NotFoundException {
		if(userRepository.existsByUsername(Username)) {
			return companyRepository.findByUserName(Username);
		}
		throw new NotFoundException("user non trovato");
	
	}
	
	public Company findById(Long id) throws NotFoundException {
		return companyRepository.findById(id).orElseThrow(()->  new NotFoundException("company non trovata"));
	}
	
	public boolean deleteById(Long id) throws NotFoundException {
		if(companyRepository.existsById(id)) {
			companyRepository.deleteById(id);
			return true;
		}
		throw new NotFoundException("company non trovata");
	}
	
	
	public void insertCompany(InsertCompanyRequestDTO dto) throws ElementAlreadyPresentException {
		if(companyRepository.existsByCompanyName(dto.getCompanyName())) {
			throw new ElementAlreadyPresentException("questa company gia esiste");
		}
		Company company = new Company();
		BeanUtils.copyProperties(dto, company);
		companyRepository.save(company);
	}
	
	
	public void UpdateCompany(Long id, InsertCompanyRequestDTO dto) throws NotFoundException {
		Company company = companyRepository.findById(id).orElseThrow(()-> new NotFoundException("company non trovata"));
		BeanUtils.copyProperties(dto, company);
		companyRepository.save(company);
	}
	
	

}
