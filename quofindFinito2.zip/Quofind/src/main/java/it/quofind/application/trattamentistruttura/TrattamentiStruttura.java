package it.quofind.application.trattamentistruttura;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import it.quofind.application.Struttura.Struttura;
import it.quofind.application.trattamento.Trattamento;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "trattamenti_struttura")
public class TrattamentiStruttura {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne
	@JoinColumn( name = "struttura_id")
	private Struttura struttura;
	@ManyToOne
	@JoinColumn( name = "trattamento_id")
	private Trattamento trattamento;

}
