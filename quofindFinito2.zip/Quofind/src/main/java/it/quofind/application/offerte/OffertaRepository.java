package it.quofind.application.offerte;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface OffertaRepository extends PagingAndSortingRepository<Offerta, Long> {

}
