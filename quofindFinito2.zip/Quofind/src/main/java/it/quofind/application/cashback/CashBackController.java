package it.quofind.application.cashback;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.quofind.application.errors.NotFoundException;

@RestController
@RequestMapping("/cashBack")
public class CashBackController {

	
	@Autowired
	CashBackService cashBackService;
	

	@Operation (summary = "Inserisce un cashback", description = "inserisce un cashback")
	@ApiResponse(responseCode = "200" , description = "cashback inserito")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated ")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@PostMapping(path = "/inserisci-cashback" ,produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity<?> inserisciCashback(@Valid @RequestBody InsertCashBackRequestDTO dto) throws NotFoundException  {
		cashBackService.insertCashBack(dto);
			return ResponseEntity.ok("CashBack inserito");
		}
	
	@Operation (summary = "modifica un cashback ", description = "modifica un cashback  ")
	@ApiResponse(responseCode = "200" , description = "modifica avvenuta")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated  ")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/modifica-cashback/{id}")
	public ResponseEntity<?> modificaCashback(@Valid @PathVariable Long id, @RequestBody InsertCashBackRequestDTO dto) throws NotFoundException {
		cashBackService.UpdateCashBack(id, dto);
		return ResponseEntity.ok("cashback modificato");
	}


	@Operation (summary = "elimina un cashback", description = "elimina un cashback")
	@ApiResponse(responseCode = "200" , description = "eliminazione avvenuta")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated ")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@DeleteMapping("/elimina-cashback")
	public ResponseEntity<?> eliminaCashback(@Valid Long id ) throws NotFoundException {
		cashBackService.delete(id);
		return ResponseEntity.ok("cashback eliminato");
	}
	
	@Operation (summary = "ritorna tutti cashback ", description = "ritorna la lista di tutti cashback ")
	@ApiResponse(responseCode = "200" , description = "lista cashback")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/get-all")
	public ResponseEntity<Page<CashBack>> tutticashback(Pageable page) {
		return ResponseEntity.ok(cashBackService.findall(page));
	}
	
	@Operation (summary = "ritorna un cashback ", description = "ritorna un cashback")
	@ApiResponse(responseCode = "200" , description = "cashback")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/get-byid/{id}")
	public ResponseEntity<CashBack> getbyid(@Valid @PathVariable Long id) throws NotFoundException {
		return ResponseEntity.ok(cashBackService.findById(id));
	}
	
	
	
	
}
