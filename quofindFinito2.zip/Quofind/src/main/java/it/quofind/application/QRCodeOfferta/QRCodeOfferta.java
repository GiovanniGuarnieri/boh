package it.quofind.application.QRCodeOfferta;

import java.time.LocalDateTime;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import it.quofind.application.offerte.Offerta;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
public class QRCodeOfferta {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private LocalDateTime dataInizioValidita;
	private LocalDateTime dataValidità;
	@ManyToOne
	@JoinColumn
	private Offerta offerta;
	
}
