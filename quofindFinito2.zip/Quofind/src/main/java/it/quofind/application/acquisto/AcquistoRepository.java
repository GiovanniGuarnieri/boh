package it.quofind.application.acquisto;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface AcquistoRepository extends PagingAndSortingRepository<Acquisto, Long> {

}
