package it.quofind.application.company;


import javax.validation.constraints.NotBlank;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class InsertCompanyRequestDTO {
	@NotBlank(message = "il campo company name è obbligatorio")
	private String companyName;
	
	private CompanyTypesEnum companyType;


	

}
