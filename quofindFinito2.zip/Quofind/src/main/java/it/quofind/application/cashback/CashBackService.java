package it.quofind.application.cashback;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.quofind.application.acquisto.Acquisto;
import it.quofind.application.acquisto.AcquistoRepository;
import it.quofind.application.errors.NotFoundException;
import it.quofind.application.user.User;
import it.quofind.application.user.UserRepository;

@Service
public class CashBackService {
	@Autowired
	CashBackRepository cashBackRepository;
	@Autowired
	AcquistoRepository acquistoRepository;
	@Autowired
	UserRepository userRepository;
	
	public Page findall(Pageable page) {
	return cashBackRepository.findAll(page);
	}
	
	
	public CashBack findById(Long id) throws NotFoundException {
		return cashBackRepository.findById(id).orElseThrow(()-> new NotFoundException("cashBack non trovato"));	
	}

	@Transactional
	public void insertCashBack(InsertCashBackRequestDTO dto) throws NotFoundException {
		CashBack cashBack = new CashBack();
		BeanUtils.copyProperties(dto, cashBack);
		Acquisto acquisto =  acquistoRepository.findById(dto.getAcquistoId()).orElseThrow(() -> new NotFoundException("acquisto non trovato"));
		User user = userRepository.findByUsername(dto.getUserId()).orElseThrow(() -> new NotFoundException("user non trovato"));
		cashBack.setAcquisto(acquisto);
		acquisto.getCashBack().add(cashBack);
		cashBackRepository.save(cashBack);
	}
	@Transactional
	public void  UpdateCashBack(Long id, InsertCashBackRequestDTO dto) throws NotFoundException {
		CashBack cashBack = cashBackRepository.findById(id).orElseThrow(() -> new NotFoundException("cashBack non trovato"));
		BeanUtils.copyProperties(dto, cashBack);
		Acquisto acquisto =  acquistoRepository.findById(dto.getAcquistoId()).orElseThrow(() -> new NotFoundException("acquisto non trovato"));
		User user = userRepository.findByUsername(dto.getUserId()).orElseThrow(() -> new NotFoundException("user non trovato"));
		cashBack.setAcquisto(acquisto);
		acquisto.getCashBack().add(cashBack);
		cashBackRepository.save(cashBack);
	}
	
	public boolean delete(Long id) throws NotFoundException {
		if(cashBackRepository.existsById(id)) {
			cashBackRepository.deleteById(id);
			return true;
		}
		throw new NotFoundException("cashback non trovato");
		
	}
}
