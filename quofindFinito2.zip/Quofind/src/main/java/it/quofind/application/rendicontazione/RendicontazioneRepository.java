package it.quofind.application.rendicontazione;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface RendicontazioneRepository extends PagingAndSortingRepository<Rendicontazione, Long> {

}
