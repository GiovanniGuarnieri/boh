package it.quofind.application.Struttura;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import it.quofind.application.company.Company;
import it.quofind.application.localita.Localita;
import it.quofind.application.trattamentistruttura.TrattamentiStruttura;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "struttura")
public class Struttura {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String descrizione;
	@ManyToOne
	@JoinColumn(name = "id_localita")
	private Localita localita;
	@ManyToOne
	@JoinColumn(name = "id_company")
	private Company company;
	@OneToMany(mappedBy = "struttura")
	private List<TrattamentiStruttura> trattamentiStruttura = new ArrayList<>();
	

	

}
