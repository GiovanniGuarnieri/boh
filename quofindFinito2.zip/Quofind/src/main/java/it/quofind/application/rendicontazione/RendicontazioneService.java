package it.quofind.application.rendicontazione;
import java.util.regex.Pattern;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.quofind.application.errors.ElementAlreadyPresentException;
import it.quofind.application.errors.NotFoundException;
import it.quofind.application.user.User;
import it.quofind.application.user.UserRepository;



@Service
public class RendicontazioneService {

	@Autowired
	RendicontazioneRepository rendicontazioneRepository;
	@Autowired
	UserRepository ur;

	public void insert(InsertRendicontazioneRequestDTO dto) throws NotFoundException, ElementAlreadyPresentException {
		Rendicontazione rendicontazione = new Rendicontazione();
		BeanUtils.copyProperties(dto, rendicontazione);
		if(dto.getTipoRendicontazione().equalsIgnoreCase("fidelizzazione")) {
			rendicontazione.setTipoRendicontazione(TipoRendicontazioneEnum.FIDELIZZAZIONE);
		}else if(dto.getTipoRendicontazione().equalsIgnoreCase("leader")) {
			rendicontazione.setTipoRendicontazione(TipoRendicontazioneEnum.LEADER);
		}else if(dto.getTipoRendicontazione().equalsIgnoreCase("commissione")) {
			rendicontazione.setTipoRendicontazione(TipoRendicontazioneEnum.COMMISSIONE);
		}else if(dto.getTipoRendicontazione().equalsIgnoreCase("recensione")) {
			rendicontazione.setTipoRendicontazione(TipoRendicontazioneEnum.RECENSIONE);
		}else {
			throw new NotFoundException("il tipo di rendicontazione non disponibile");
		}if(dto.getMese()<0|| dto.getMese()> 12) {
			throw new NotFoundException("il campo mese deve essere un numero da 1 a 12");
		}
		User userName = ur.findByUsername(dto.getUserName()).orElseThrow(()-> new NotFoundException("User non trovato"));
		User userCorrelato = ur.findByUsername(dto.getUserCorrelato()).orElseThrow(()-> new NotFoundException("User non trovato"));
		
		if(!Pattern.matches("^[12][0-9]{3}$", String.valueOf(dto.getAnno()))) {
		throw new NotFoundException("l'anno deve essere composto da 4 cifre");
		}
		rendicontazione.setUserName(userName);
		rendicontazione.setUserCorrelato(userCorrelato);
		userName.getRenticontazioni().add(rendicontazione);
		userCorrelato.getRenticontazioniCorellate().add(rendicontazione);
		rendicontazioneRepository.save(rendicontazione);
	}



	public void update(Long id, InsertRendicontazioneRequestDTO dto) throws NotFoundException {
		Rendicontazione rendicontazione = rendicontazioneRepository.findById(id).orElseThrow(()-> new NotFoundException("rendicontazione non trovata"));
		BeanUtils.copyProperties(dto, rendicontazione);
		if(dto.getTipoRendicontazione().equalsIgnoreCase("fidelizzazione")) {
			rendicontazione.setTipoRendicontazione(TipoRendicontazioneEnum.FIDELIZZAZIONE);
		}else if(dto.getTipoRendicontazione().equalsIgnoreCase("leader")) {
			rendicontazione.setTipoRendicontazione(TipoRendicontazioneEnum.LEADER);
		}else if(dto.getTipoRendicontazione().equalsIgnoreCase("commissione")) {
			rendicontazione.setTipoRendicontazione(TipoRendicontazioneEnum.COMMISSIONE);
		}else if(dto.getTipoRendicontazione().equalsIgnoreCase("recensione")) {
			rendicontazione.setTipoRendicontazione(TipoRendicontazioneEnum.RECENSIONE);
		}else {
			throw new NotFoundException("il tipo di rendicontazione non disponibile");
		}
		if(dto.getMese()<0|| dto.getMese()> 12) {
			throw new NotFoundException("il campo mese deve essere un numero da 1 a 12");
		}
		User userName = ur.findByUsername(dto.getUserName()).orElseThrow(()-> new NotFoundException("User non trovato"));
		User userCorrelato = ur.findByUsername(dto.getUserCorrelato()).orElseThrow(()-> new NotFoundException("User non trovato"));
		if(!Pattern.matches("^[12][0-9]{3}$", String.valueOf(dto.getAnno()))) {
			throw new NotFoundException("l'anno deve essere composto da 4 cifre");
		}
		rendicontazione.setUserName(userName);
		rendicontazione.setUserCorrelato(userCorrelato);
		userName.getRenticontazioni().add(rendicontazione);
		userCorrelato.getRenticontazioniCorellate().add(rendicontazione);
		rendicontazioneRepository.save(rendicontazione);
	}


	public Rendicontazione getById(Long id) throws NotFoundException {
		return rendicontazioneRepository.findById(id).orElseThrow(()-> new NotFoundException("rendicontazione non trovata"));
	}


	public Page getAll(Pageable pageable) {
		return rendicontazioneRepository.findAll(pageable);
	}

	public Boolean delete(Long id) throws NotFoundException {
		if(rendicontazioneRepository.existsById(id)) {
			rendicontazioneRepository.deleteById(id);
			return true;
		}
		throw new NotFoundException("rendicontazione non trovata");
	}
}
