package it.quofind.application.statovenditecollaboratore;

import java.time.LocalDateTime;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class InsertStatoVenditaCollaboratoreRequestDTO {
	static final String DATETIME_PATTERN ="dd/MM/yyyy HH:mm:ss";
	
	@JsonFormat(pattern = DATETIME_PATTERN)
	private LocalDateTime dataAggiornamento;
	@NotNull(message = "il campo attive è obbligatorio")
	boolean attive;
	@NotNull(message = "il campo collaboratore_id è obbligatorio")
	@JsonProperty(value = "collaboratore_id")
	private Long collaboratoreId;

	@NotNull(message = "il campo cancellateCliente è obbligatorio")
	Integer cancellateCliente;
	@NotNull(message = "il campo cancellateVenditore è obbligatorio")
	Integer cancellateVenditore;
	@NotNull(message = "il campo cancellabili è obbligatorio")
	Integer cancellabili;
	@NotNull(message = "il campo nonCancellabili è obbligatorio")
	Integer nonCancellabili;
	@NotNull(message = "il campo mese è obbligatorio")
	Integer mese;
	@NotNull(message = "il campo anno è obbligatorio")
	Integer anno;
}
