package it.quofind.application.rendicontazione;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import it.quofind.application.errors.ElementAlreadyPresentException;
import it.quofind.application.errors.NotFoundException;

@RestController
@RequestMapping("/rendicontazione")
public class RendicontazioneController {
	
	
	@Autowired
	RendicontazioneService qr;
	

	@Operation (summary = "Inserisce un Rendicontazione nel db", description = "inserisce un Rendicontazione nel db ")
	@ApiResponse(responseCode = "200" , description = "Rendicontazione inserito")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated ")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@PostMapping(produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity<?> inserisci(@Valid @RequestBody InsertRendicontazioneRequestDTO dto) throws NotFoundException, ElementAlreadyPresentException  {
		qr.insert(dto);
			return ResponseEntity.ok("Rendicontazione inserita");
		}
	@Operation (summary = "modifica un Rendicontazione", description = "modifica un Rendicontazione ")
	@ApiResponse(responseCode = "200" , description = "modifica avvenuta")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated  ")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/{id}")
	public ResponseEntity<?> modifica(@Valid @PathVariable Long id, @RequestBody InsertRendicontazioneRequestDTO dto) throws NotFoundException, ElementAlreadyPresentException {
		qr.update(id, dto);
		return ResponseEntity.ok("Rendicontazione modificato");
	}


	@Operation (summary = "elimina un Rendicontazione", description = "elimina un Rendicontazione")
	@ApiResponse(responseCode = "200" , description = "eliminazione Rendicontazione")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated ")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@DeleteMapping("")
	public ResponseEntity<?> elimina(@Valid Long id ) throws NotFoundException {
		qr.delete(id);
		return ResponseEntity.ok("Rendicontazione eliminato");
	}
	
	@Operation (summary = "ritorna tutti Rendicontazione ", description = "ritorna la lista di Rendicontazione")
	@ApiResponse(responseCode = "200" , description = "lista Rendicontazione")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("")
	public ResponseEntity<Page<Rendicontazione>> getAll(Pageable page) {
		return ResponseEntity.ok(qr.getAll(page));
	}
	
	@Operation (summary = "ritorna un Rendicontazione ", description = "ritorna un Rendicontazione ")
	@ApiResponse(responseCode = "200" , description = "Rendicontazione")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/{id}")
	public ResponseEntity<Rendicontazione> getAll(@Valid @PathVariable Long id) throws NotFoundException {
		return ResponseEntity.ok(qr.getById(id));
	}

}
