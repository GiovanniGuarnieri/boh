package it.quofind.application.statovenditevenditore;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import it.quofind.application.errors.NotFoundException;

@RestController
@RequestMapping("/statoVenditaVenditore")
public class StatoVenditaVenditoreController {
	@Autowired
	StatoVenditaVenditoreService statoVenditaVenditoreService;
	
	@Operation(summary = "Inserisci uno statoVenditaVenditore", description = "Inserisci uno statoVenditaVenditore")
	@ApiResponse(responseCode = "200", description = "statoVenditaVenditore inserito")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@PostMapping(produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity<?> inserisciStatoVenditaVenditore(@Valid @RequestBody InsertStatoVenditaVenditoreRequestDTO dto) throws NotFoundException  {
		statoVenditaVenditoreService.insertStatoVenditaVenditore(dto);
		return ResponseEntity.ok("StatoVenditaVenditore inserito");
	}
	
	@Operation (summary = "modifica uno statoVenditaVenditore", description = "modifica uno statoVenditaVenditore")
	@ApiResponse(responseCode = "200" , description = "modifica avvenuta")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated  ")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@PutMapping
	public ResponseEntity<?> modificaStatoVenditaVenditore(@Valid @PathVariable Long id, @RequestBody InsertStatoVenditaVenditoreRequestDTO dto) throws NotFoundException {
		statoVenditaVenditoreService.updateStatoVenditaVenditore(id, dto);
		return ResponseEntity.ok("statoVenditaVenditore modificato");
	}


	@Operation (summary = "elimina uno statoVenditaVenditore", description = "elimina uno statoVenditaVenditore")
	@ApiResponse(responseCode = "200" , description = "eliminazione avvenuta")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated ")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@DeleteMapping
	public ResponseEntity<?> eliminaStatoVenditaVenditore(@Valid Long id ) throws NotFoundException {
		statoVenditaVenditoreService.delete(id);
		return ResponseEntity.ok("statoVenditaVenditore eliminato");
	}
	
	@Operation (summary = "ritorna tutti i statoVenditaVenditore ", description = "ritorna la lista di tutti i statoVenditaVenditore ")
	@ApiResponse(responseCode = "200" , description = "lista statoVenditaVenditore")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/get-all")
	public ResponseEntity<Page<StatoVenditaVenditore>> tuttiStatoVendite(Pageable page) {
		return ResponseEntity.ok(statoVenditaVenditoreService.findAll(page));
	}
	
	@Operation (summary = "ritorna uno statoVenditaVenditore ", description = "ritorna uno statoVenditaVenditore")
	@ApiResponse(responseCode = "200" , description = "statoVenditaVenditore")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/get-byid/{id}")
	public ResponseEntity<StatoVenditaVenditore> getbyid(@Valid @PathVariable Long id) throws NotFoundException {
		return ResponseEntity.ok(statoVenditaVenditoreService.findById(id));
	}
}
