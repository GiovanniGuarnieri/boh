package it.quofind.application.user;

import java.util.Set;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ModificaUserRequestDTO {
	
	private Long profileId;
	
	private Long companyId;
	@NotBlank
	private String userType;
	@NotBlank
	private String password;
	
	private String roles;

	
}
