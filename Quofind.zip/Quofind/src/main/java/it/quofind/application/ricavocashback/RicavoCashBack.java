package it.quofind.application.ricavocashback;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import it.quofind.application.collaboratore.Collaboratore;
import it.quofind.application.company.Company;
import it.quofind.application.user.User;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RicavoCashBack {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY )
	private Long id;
	
	private double totale;
	private double daAffiliazione;
	private double daFidelity;
	private double daLeader;
	
	@JoinColumn(name = "collaboratore_id")
	@ManyToOne
	private Collaboratore collaboratore;
	@JoinColumn(name = "company_id")
	@ManyToOne
	private Company company;
	@JoinColumn
	@ManyToOne
	private User leaderUser;
	
	private int mese;
	private int anno;
}
