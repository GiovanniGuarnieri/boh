package it.quofind.application.collaboratore;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

import it.quofind.application.ricavo.Ricavo;
import it.quofind.application.ricavocashback.RicavoCashBack;
import it.quofind.application.statovenditecollaboratore.StatoVenditaCollaboratore;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
public class Collaboratore {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@OneToMany(mappedBy = "collaboratore")
	@JsonIgnore
	private List<Ricavo>ricavi = new ArrayList<Ricavo>();
	
	@OneToMany(mappedBy = "collaboratore")
	@JsonIgnore
	private List<RicavoCashBack>ricaviCashBack = new ArrayList<RicavoCashBack>();
	
	@OneToMany(mappedBy = "collaboratore")
	@JsonIgnore
	private List<StatoVenditaCollaboratore>statoVendite = new ArrayList<StatoVenditaCollaboratore>();

}
