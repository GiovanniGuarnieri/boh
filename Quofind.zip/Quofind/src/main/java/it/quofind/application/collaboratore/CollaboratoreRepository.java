package it.quofind.application.collaboratore;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface CollaboratoreRepository extends PagingAndSortingRepository<Collaboratore, Long> {

}

