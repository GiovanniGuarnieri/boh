package it.quofind.application.ricavocashback;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface RicavoCashBackRepository extends PagingAndSortingRepository<RicavoCashBack, Long>{

}
