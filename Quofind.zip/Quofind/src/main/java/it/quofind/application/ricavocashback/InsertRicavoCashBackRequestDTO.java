package it.quofind.application.ricavocashback;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class InsertRicavoCashBackRequestDTO {
	@NotNull(message = "il campo totale è obbligatorio")
	private double totale;
	@NotNull(message = "il campo daAffiliazione è obbligatorio")
	private double daAffiliazione;
	private double daFidelity;
	private double daLeader;
	
	@NotNull(message = "il campo collaboratore_id è obbligatorio")
	@JsonProperty(value = "collaboratore_id")
	private Long collaboratoreId;
	@NotNull(message = "il campo company_id è obbligatorio")
	@JsonProperty(value = "company_id")
	private Long companyId;
	@NotNull(message = "il campo user_id non può essere null")
	private String userId;
	
	@NotNull(message = "il campo mese è obbligatorio")
	private int mese;
	@NotNull(message = "il campo anno è obbligatorio")
	private int anno;
}
