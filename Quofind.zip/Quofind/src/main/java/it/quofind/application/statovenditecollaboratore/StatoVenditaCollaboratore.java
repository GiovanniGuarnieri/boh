package it.quofind.application.statovenditecollaboratore;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import it.quofind.application.collaboratore.Collaboratore;
import it.quofind.application.company.Company;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "StatoVenditaCollaboratore")
public class StatoVenditaCollaboratore {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private LocalDateTime dataAggiornamento;
	boolean attive;
	@JoinColumn(name = "collaboratore_id")
	@ManyToOne
	private Collaboratore collaboratore;
	
	Integer cancellateCliente;
	Integer cancellateVenditore;
	Integer cancellabili;
	Integer nonCancellabili;
	Integer mese;
	Integer anno;

}
