package it.quofind.application.ricavo;

import java.util.regex.Pattern;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import it.quofind.application.ricavocashback.RicavoCashBack;
import it.quofind.application.ricavocashback.RicavoCashBackRepository;
import it.quofind.application.collaboratore.Collaboratore;
import it.quofind.application.collaboratore.CollaboratoreRepository;
import it.quofind.application.company.Company;
import it.quofind.application.company.CompanyRepository;
import it.quofind.application.errors.ElementAlreadyPresentException;
import it.quofind.application.errors.NotFoundException;
import lombok.extern.slf4j.Slf4j;


@Service
public class RicavoService {

	@Autowired
	RicavoRepository ricavoRepository;
	@Autowired
	CollaboratoreRepository collaboratoreRepository;
	@Autowired
	CompanyRepository companyRepository;
	
	public Page<Ricavo> findAll(Pageable page) {
		return ricavoRepository.findAll(page);
	}


	public Ricavo findById(Long id) throws NotFoundException {
		return ricavoRepository.findById(id).orElseThrow(()-> new NotFoundException("elemento non trovato"));
	}


	public boolean delete(Long id) throws NotFoundException {
		if(ricavoRepository.existsById(id)) {
			ricavoRepository.deleteById(id);
			return true;
		}
		throw new NotFoundException("elemento non trovato");
	}

	@Transactional
	public void insertRicavo(InsertRicavoRequestDTO dto) throws NotFoundException {
		Ricavo ricavo = new Ricavo();
		BeanUtils.copyProperties(dto, ricavo);
		if(dto.getMese() < 0 || dto.getMese() > 12) {
			throw new NotFoundException("il mese deve essere un numero da 1 a 12");
		}
		if(!Pattern.matches("^[12][0-9]{3}$", String.valueOf(dto.getAnno()))) {
			throw new NotFoundException("l'anno deve essere composto da 4 cifre");
		}
		Collaboratore collaboratore = collaboratoreRepository.findById(dto.getCollaboratoreId()).orElseThrow(() -> new NotFoundException("collaboratore non trovato"));
		ricavo.setCollaboratore(collaboratore);
		collaboratore.getRicavi().add(ricavo);
		Company company = companyRepository.findById(dto.getCompanyId()).orElseThrow(() -> new NotFoundException("company non trovata"));
		ricavo.setCompany(company);
		company.getRicavi().add(ricavo);
		ricavoRepository.save(ricavo);

	}

	@Transactional
	public void updateRicavo(Long id ,InsertRicavoRequestDTO dto) throws NotFoundException {
		Ricavo ricavo = ricavoRepository.findById(id).orElseThrow(()-> new NotFoundException("ricavo non trovato"));
		BeanUtils.copyProperties(dto, ricavo);
		if(dto.getMese() < 0 || dto.getMese() > 12) {
			throw new NotFoundException("il mese deve essere un numero da 1 a 12");
		}
		if(!Pattern.matches("^[12][0-9]{3}$", String.valueOf(dto.getAnno()))) {
			throw new NotFoundException("l'anno deve essere composto da 4 cifre");
		}
		Collaboratore collaboratore = collaboratoreRepository.findById(dto.getCollaboratoreId()).orElseThrow(() -> new NotFoundException("collaboratore non trovato"));
		ricavo.setCollaboratore(collaboratore);
		collaboratore.getRicavi().add(ricavo);
		Company company = companyRepository.findById(dto.getCompanyId()).orElseThrow(() -> new NotFoundException("company non trovata"));
		ricavo.setCompany(company);
		company.getRicavi().add(ricavo);
		ricavoRepository.save(ricavo);
	}
}
