package it.quofind.application.QRCodeOfferta;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface QRCodeOffertaRepository extends PagingAndSortingRepository<QRCodeOfferta, Long> {

}
