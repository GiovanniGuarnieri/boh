package it.quofind.application.acquisto;



import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import it.quofind.application.cashback.CashBack;
import it.quofind.application.cashback.CashBackRepository;
import it.quofind.application.company.Company;
import it.quofind.application.company.CompanyRepository;
import it.quofind.application.errors.ElementAlreadyPresentException;
import it.quofind.application.errors.NotFoundException;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AcquistoService {

	@Autowired
	AcquistoRepository acquistoRepository;
	@Autowired
	CompanyRepository companyRepository;
	


	public Page<Acquisto> findAll(Pageable page) {
		return acquistoRepository.findAll(page);
	}


	public Acquisto findById(Long id) throws NotFoundException {
		return acquistoRepository.findById(id).orElseThrow(()-> new NotFoundException("elemento non trovato"));
	}


	public boolean delete(Long id) throws NotFoundException {
		if(acquistoRepository.existsById(id)) {
			acquistoRepository.deleteById(id);
			return true;
		}
		throw new NotFoundException("elemento non trovato");
	}

	@Transactional
	public void insertAcquisto(InsertAcquistoRequestDTO dto) throws NotFoundException {
		Acquisto acquisto = new Acquisto();
		BeanUtils.copyProperties(dto, acquisto);
		Company company = companyRepository.findById(dto.getCompanyId()).orElseThrow(() -> new NotFoundException("company non trovata"));
		acquisto.setCompany(company);
		company.getAcquisti().add(acquisto);
		acquistoRepository.save(acquisto);

	}

	@Transactional
	public void updateAcquisto(Long id ,InsertAcquistoRequestDTO dto) throws NotFoundException {
		Acquisto acquisto = acquistoRepository.findById(id).orElseThrow(()-> new NotFoundException("acquisto non trovato"));
		BeanUtils.copyProperties(dto, acquisto);
		Company company = companyRepository.findById(dto.getCompanyId()).orElseThrow(() -> new NotFoundException("company non trovata"));
		acquisto.setCompany(company);
		company.getAcquisti().add(acquisto);
		acquistoRepository.save(acquisto);
	}

}
