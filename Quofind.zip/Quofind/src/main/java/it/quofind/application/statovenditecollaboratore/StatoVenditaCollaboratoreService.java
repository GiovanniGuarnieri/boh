
package it.quofind.application.statovenditecollaboratore;

import java.util.regex.Pattern;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import it.quofind.application.collaboratore.Collaboratore;
import it.quofind.application.collaboratore.CollaboratoreRepository;
import it.quofind.application.errors.NotFoundException;

@Service
public class StatoVenditaCollaboratoreService {
	@Autowired
	StatoVenditaCollaboratoreRepository statoVenditaCollaboratoreRepository;
	@Autowired
	CollaboratoreRepository collaboratoreRepository;
	
	public Page findAll(Pageable page) {
		return statoVenditaCollaboratoreRepository.findAll(page);
	}
	
	public StatoVenditaCollaboratore findById(Long id) throws NotFoundException {
		return statoVenditaCollaboratoreRepository.findById(id).orElseThrow(()-> new NotFoundException("statoVenditaCollaboratore non trovato"));
	}
	
	@Transactional
	public void insertStatoVenditaCollaboratore(InsertStatoVenditaCollaboratoreRequestDTO dto) throws NotFoundException {
		StatoVenditaCollaboratore svc = new StatoVenditaCollaboratore();
		BeanUtils.copyProperties(dto, svc);
		if(dto.getMese() < 0 || dto.getMese() > 12) {
			throw new NotFoundException("il mese deve essere un numero da 1 a 12");
		}
		if(!Pattern.matches("^[12][0-9]{3}$", String.valueOf(dto.getAnno()))) {
			throw new NotFoundException("l'anno deve essere composto da 4 cifre");
		}
		Collaboratore col = collaboratoreRepository.findById(dto.getCollaboratoreId()).orElseThrow(() -> new NotFoundException("collaboratore non trovato"));
		svc.setCollaboratore(col);
		col.getStatoVendite().add(svc);
		statoVenditaCollaboratoreRepository.save(svc);
	}
	
	@Transactional
	public void updateStatoVenditaCollaboratore(Long id, InsertStatoVenditaCollaboratoreRequestDTO dto) throws NotFoundException {
		StatoVenditaCollaboratore svc = statoVenditaCollaboratoreRepository.findById(id).orElseThrow(() -> new NotFoundException("statoVenditaCollaboratore non trovato"));
		BeanUtils.copyProperties(dto, svc);
		if(dto.getMese() < 0 || dto.getMese() > 12) {
			throw new NotFoundException("il mese deve essere un numero da 1 a 12");
		}
		if(!Pattern.matches("^[12][0-9]{3}$", String.valueOf(dto.getAnno()))) {
			throw new NotFoundException("l'anno deve essere composto da 4 cifre");
		}
		Collaboratore col = collaboratoreRepository.findById(dto.getCollaboratoreId()).orElseThrow(() -> new NotFoundException("collaboratore non trovato"));
		svc.setCollaboratore(col);
		col.getStatoVendite().add(svc);
		statoVenditaCollaboratoreRepository.save(svc);
	}
	
	public boolean delete(Long id) throws NotFoundException {
		if (statoVenditaCollaboratoreRepository.existsById(id)) {
			statoVenditaCollaboratoreRepository.deleteById(id);
			return true;
		}
		throw new NotFoundException("statoVenditaCollaboratoreRepository non trovato");
	}

}