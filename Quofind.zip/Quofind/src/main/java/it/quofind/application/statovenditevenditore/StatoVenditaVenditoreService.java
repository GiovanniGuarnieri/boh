package it.quofind.application.statovenditevenditore;

import java.util.regex.Pattern;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import it.quofind.application.company.Company;
import it.quofind.application.company.CompanyRepository;
import it.quofind.application.errors.NotFoundException;

@Service
public class StatoVenditaVenditoreService {
	@Autowired
	StatoVenditaVenditoreRepository statoVenditaVenditoreRepository;
	@Autowired
	CompanyRepository companyRepository;
	
	public Page findAll(Pageable page) {
		return statoVenditaVenditoreRepository.findAll(page);
	}
	
	public StatoVenditaVenditore findById(Long id) throws NotFoundException {
		return statoVenditaVenditoreRepository.findById(id).orElseThrow(()-> new NotFoundException("statoVenditaVenditore non trovato"));
	}
	
	@Transactional
	public void insertStatoVenditaVenditore(InsertStatoVenditaVenditoreRequestDTO dto) throws NotFoundException {
		StatoVenditaVenditore svv = new StatoVenditaVenditore();
		BeanUtils.copyProperties(dto, svv);
		if(dto.getMese() < 0 || dto.getMese() > 12) {
			throw new NotFoundException("il mese deve essere un numero da 1 a 12");
		}
		if(!Pattern.matches("^[12][0-9]{3}$", String.valueOf(dto.getAnno()))) {
			throw new NotFoundException("l'anno deve essere composto da 4 cifre");
		}
		Company co = companyRepository.findById(dto.getCompanyId()).orElseThrow(() -> new NotFoundException("company non trovata"));
		svv.setCompany(co);
		co.getStatoVendite().add(svv);
		statoVenditaVenditoreRepository.save(svv);
	}
	
	@Transactional
	public void updateStatoVenditaVenditore(Long id, InsertStatoVenditaVenditoreRequestDTO dto) throws NotFoundException {
		StatoVenditaVenditore svv = statoVenditaVenditoreRepository.findById(id).orElseThrow(() -> new NotFoundException("statoVenditaVenditore non trovato"));
		BeanUtils.copyProperties(dto, svv);
		if(dto.getMese() < 0 || dto.getMese() > 12) {
			throw new NotFoundException("il mese deve essere un numero da 1 a 12");
		}
		if(!Pattern.matches("^[12][0-9]{3}$", String.valueOf(dto.getAnno()))) {
			throw new NotFoundException("l'anno deve essere composto da 4 cifre");
		}
		Company co = companyRepository.findById(dto.getCompanyId()).orElseThrow(() -> new NotFoundException("company non trovata"));
		svv.setCompany(co);
		co.getStatoVendite().add(svv);
		statoVenditaVenditoreRepository.save(svv);
	}
	
	public boolean delete(Long id) throws NotFoundException {
		if (statoVenditaVenditoreRepository.existsById(id)) {
			statoVenditaVenditoreRepository.deleteById(id);
			return true;
		}
		throw new NotFoundException("statoVenditaVenditoreRepository non trovato");
	}

}
