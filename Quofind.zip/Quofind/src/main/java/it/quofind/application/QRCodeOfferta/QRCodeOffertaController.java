package it.quofind.application.QRCodeOfferta;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

import it.quofind.application.errors.NotFoundException;

@RestController
@RequestMapping("QRCodeOfferta")
public class QRCodeOffertaController {

	@Autowired
	QRCodeOffertaService qr;
	

	@Operation (summary = "Inserisce un QRCodeOfferta nel db", description = "inserisce un QRCodeOfferta nel db ")
	@ApiResponse(responseCode = "200" , description = "QRCodeOfferta inserito")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated ")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@PostMapping(produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity<?> inserisci(@Valid @RequestBody InsertQrRequestDTO dto) throws NotFoundException  {
		qr.insert(dto);
			return ResponseEntity.ok("QRCodeOfferta inserita");
		}
	@Operation (summary = "modifica un QRCodeOfferta", description = "modifica un QRCodeOfferta ")
	@ApiResponse(responseCode = "200" , description = "modifica avvenuta")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated  ")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/{id}")
	public ResponseEntity<?> modifica(@Valid @PathVariable Long id, @RequestBody InsertQrRequestDTO dto) throws NotFoundException {
		qr.update(id, dto);
		return ResponseEntity.ok("QRCodeOfferta modificato");
	}


	@Operation (summary = "elimina un QRCodeOfferta", description = "elimina un QRCodeOfferta")
	@ApiResponse(responseCode = "200" , description = "eliminazione QRCodeOfferta")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated ")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@DeleteMapping("")
	public ResponseEntity<?> elimina(@Valid Long id ) throws NotFoundException {
		qr.delete(id);
		return ResponseEntity.ok("QRCodeOfferta eliminato");
	}
	
	@Operation (summary = "ritorna tutti QRCodeOfferta ", description = "ritorna la lista di QRCodeOfferta")
	@ApiResponse(responseCode = "200" , description = "lista QRCodeOfferta")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("")
	public ResponseEntity<Page<QRCodeOfferta>> tutteQRCodeOfferta(Pageable page) {
		return ResponseEntity.ok(qr.getAll(page));
	}
	
	@Operation (summary = "ritorna un QRCodeOfferta ", description = "ritorna un QRCodeOfferta ")
	@ApiResponse(responseCode = "200" , description = "QRCodeOfferta")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/{id}")
	public ResponseEntity<QRCodeOfferta> getAll(@Valid @PathVariable Long id) throws NotFoundException {
		return ResponseEntity.ok(qr.getId(id));
	}
}
