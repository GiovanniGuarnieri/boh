package it.quofind.application.trattamentistruttura;

import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class InsertTrattamentiStrutturaRequestDTO {

	@NotNull(message = "il campo strutturaid non può essere null")
	private Long strutturaId;
	@NotNull(message = "il campo trattamentoid non può essere null")
	private Long trattamentoId;
}
