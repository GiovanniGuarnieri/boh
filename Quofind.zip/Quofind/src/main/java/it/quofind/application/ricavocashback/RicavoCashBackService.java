package it.quofind.application.ricavocashback;


import java.util.regex.Pattern;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import it.quofind.application.collaboratore.Collaboratore;
import it.quofind.application.collaboratore.CollaboratoreRepository;
import it.quofind.application.company.Company;
import it.quofind.application.company.CompanyRepository;
import it.quofind.application.errors.NotFoundException;
import it.quofind.application.user.User;
import it.quofind.application.user.UserRepository;

@Service
public class RicavoCashBackService {
	@Autowired
	RicavoCashBackRepository ricavoCashBackRepository;
	@Autowired
	CollaboratoreRepository collaboratoreRepository;
	@Autowired
	CompanyRepository companyRepository;
	@Autowired
	UserRepository userRepository;
	
	public Page findAll(Pageable page) {
		return ricavoCashBackRepository.findAll(page);
	}
	
	public RicavoCashBack findById(Long id) throws NotFoundException {
		return ricavoCashBackRepository.findById(id).orElseThrow(()-> new NotFoundException("ricavoCashBack non trovato"));
	}
	
	@Transactional
	public void insertRicavoCashBack(InsertRicavoCashBackRequestDTO dto) throws NotFoundException {
		RicavoCashBack rcb = new RicavoCashBack();
		BeanUtils.copyProperties(dto, rcb);
		if(dto.getMese() < 0 || dto.getMese() > 12) {
			throw new NotFoundException("il mese deve essere un numero da 1 a 12");
		}
		if(!Pattern.matches("^[12][0-9]{3}$", String.valueOf(dto.getAnno()))) {
			throw new NotFoundException("l'anno deve essere composto da 4 cifre");
		}
		Collaboratore col = collaboratoreRepository.findById(dto.getCollaboratoreId()).orElseThrow(() -> new NotFoundException("collaboratore non trovato"));
		rcb.setCollaboratore(col);
		col.getRicaviCashBack().add(rcb);
		Company co = companyRepository.findById(dto.getCompanyId()).orElseThrow(() -> new NotFoundException("company non trovata"));
		rcb.setCompany(co);
		co.getRicaviCashBack().add(rcb);
		User user = userRepository.findByUsername(dto.getUserId()).orElseThrow(() -> new NotFoundException("user non trovato"));
		rcb.setLeaderUser(user);
		user.getRicaviCashBack().add(rcb);
		ricavoCashBackRepository.save(rcb);
	}
	
	@Transactional
	public void updateRicavoCashBack(Long id, InsertRicavoCashBackRequestDTO dto) throws NotFoundException {
		RicavoCashBack rcb = ricavoCashBackRepository.findById(id).orElseThrow(() -> new NotFoundException("ricavoCashBack non trovato"));
		BeanUtils.copyProperties(dto, rcb);
		if(dto.getMese() < 0 || dto.getMese() > 12) {
			throw new NotFoundException("il mese deve essere un numero da 1 a 12");
		}
		if(!Pattern.matches("^[12][0-9]{3}$", String.valueOf(dto.getAnno()))) {
			throw new NotFoundException("l'anno deve essere composto da 4 cifre");
		}
		Collaboratore col = collaboratoreRepository.findById(dto.getCollaboratoreId()).orElseThrow(() -> new NotFoundException("collaboratore non trovato"));
		rcb.setCollaboratore(col);
		col.getRicaviCashBack().add(rcb);
		Company co = companyRepository.findById(dto.getCompanyId()).orElseThrow(() -> new NotFoundException("company non trovata"));
		rcb.setCompany(co);
		co.getRicaviCashBack().add(rcb);
		User user = userRepository.findByUsername(dto.getUserId()).orElseThrow(() -> new NotFoundException("user non trovato"));
		rcb.setLeaderUser(user);
		user.getRicaviCashBack().add(rcb);
		ricavoCashBackRepository.save(rcb);
	}
	
	public boolean delete(Long id) throws NotFoundException {
		if (ricavoCashBackRepository.existsById(id)) {
			ricavoCashBackRepository.deleteById(id);
			return true;
		}
		throw new NotFoundException("ricavoCashBack non trovato");
	}
}
