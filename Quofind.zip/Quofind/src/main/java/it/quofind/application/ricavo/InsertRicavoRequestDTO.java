package it.quofind.application.ricavo;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import it.quofind.application.collaboratore.Collaboratore;
import it.quofind.application.company.Company;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InsertRicavoRequestDTO {
	@NotNull(message = "il campo totale è obbligatorio")
	private double totale;
	@NotNull(message = "il campo commissione è obbligatorio")
	private double commissione;
	@NotBlank(message = "il campo commissionePerc è obbligatorio")
	private double commissionePerc;
	@NotNull(message = "il campo collaboratore_id è obbligatorio")
	@JsonProperty(value = "collaboratore_id")
	private Long collaboratoreId;
	@NotNull(message = "il campo company_id è obbligatorio")
	@JsonProperty(value = "company_id")
	private Long companyId;
	@NotNull(message = "il campo mese è obbligatorio")
	private int mese;
	@NotNull(message = "il campo anno è obbligatorio")
	private int anno;
}
