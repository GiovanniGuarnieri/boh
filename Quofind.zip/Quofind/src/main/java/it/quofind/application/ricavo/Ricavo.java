package it.quofind.application.ricavo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import it.quofind.application.collaboratore.Collaboratore;
import it.quofind.application.company.Company;
import it.quofind.application.ricavocashback.RicavoCashBack;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "Ricavo")
public class Ricavo {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private double totale;
	private double commissione;
	private double commissionePerc;
	@JoinColumn(name = "collaboratore_id")
	@ManyToOne
	private Collaboratore collaboratore;
	@JoinColumn(name = "company_id")
	@ManyToOne
	private Company company;
	@JsonIgnoreProperties({"ricavo"})
	private int mese;
	private int anno;
	
}
