package it.quofind.application.ricavocashback;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import it.quofind.application.cashback.CashBack;
import it.quofind.application.errors.NotFoundException;

@RestController
@RequestMapping("/ricavoCashBack")
public class RicavoCashBackController {
	@Autowired
	RicavoCashBackService ricavoCashBackService;
	
	@Operation(summary = "Inserisci un ricavoCashBack", description = "Inserisci un ricavoCashBack")
	@ApiResponse(responseCode = "200", description = "ricavoCashBack inserito")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@PostMapping(produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity<?> inserisciRicavoCashBack(@Valid @RequestBody InsertRicavoCashBackRequestDTO dto) throws NotFoundException  {
		ricavoCashBackService.insertRicavoCashBack(dto);
		return ResponseEntity.ok("RicavoCashBack inserito");
	}
	
	@Operation (summary = "modifica un ricavoCashBack ", description = "modifica un ricavoCashBack  ")
	@ApiResponse(responseCode = "200" , description = "modifica avvenuta")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated  ")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@PutMapping
	public ResponseEntity<?> modificaRicavoCashBack(@Valid @PathVariable Long id, @RequestBody InsertRicavoCashBackRequestDTO dto) throws NotFoundException {
		ricavoCashBackService.updateRicavoCashBack(id, dto);
		return ResponseEntity.ok("ricavoCashBack modificato");
	}


	@Operation (summary = "elimina un ricavoCashBack", description = "elimina un ricavoCashBack")
	@ApiResponse(responseCode = "200" , description = "eliminazione avvenuta")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated ")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@DeleteMapping
	public ResponseEntity<?> eliminaRicavoCashBack(@Valid Long id ) throws NotFoundException {
		ricavoCashBackService.delete(id);
		return ResponseEntity.ok("ricavoCashBack eliminato");
	}
	
	@Operation (summary = "ritorna tutti i ricaviCashBack ", description = "ritorna la lista di tutti i ricaviCashBack ")
	@ApiResponse(responseCode = "200" , description = "lista ricaviCashBack")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/get-all")
	public ResponseEntity<Page<CashBack>> tuttiRicaviCashBack(Pageable page) {
		return ResponseEntity.ok(ricavoCashBackService.findAll(page));
	}
	
	@Operation (summary = "ritorna un ricavoCashBack ", description = "ritorna un ricavoCashBack")
	@ApiResponse(responseCode = "200" , description = "ricavoCashBack")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/get-byid/{id}")
	public ResponseEntity<RicavoCashBack> getbyid(@Valid @PathVariable Long id) throws NotFoundException {
		return ResponseEntity.ok(ricavoCashBackService.findById(id));
	}
}
