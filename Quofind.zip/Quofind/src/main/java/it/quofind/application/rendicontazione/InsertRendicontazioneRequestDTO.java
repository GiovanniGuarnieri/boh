package it.quofind.application.rendicontazione;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class InsertRendicontazioneRequestDTO {

	@NotBlank
	private String userName;
	@NotBlank
	private String userCorrelato ;
	@NotBlank
	private String tipoRendicontazione;
	@NotNull(message = "il campo mese non può essere vuoto")
	private int mese;
	@NotNull(message = "il campo anno non può essere vuoto")
	private int anno;
	
	
	
}
