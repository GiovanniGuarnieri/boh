package it.quofind.application.rendicontazione;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import it.quofind.application.user.User;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@Data
public class Rendicontazione {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne
	@JoinColumn
	private User userName;
	@ManyToOne
	@JoinColumn
	private User userCorrelato ;
	@Enumerated(EnumType.STRING)
	private TipoRendicontazioneEnum tipoRendicontazione;
	
	private int mese;
	
	private int anno;
	
}
