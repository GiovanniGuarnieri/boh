package it.quofind.application.ricavo;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface RicavoRepository  extends PagingAndSortingRepository<Ricavo, Long> {

}
