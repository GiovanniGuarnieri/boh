package it.quofind.application.ricavo;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import it.quofind.application.errors.NotFoundException;

@RestController
@RequestMapping("/ricavo")
public class RicavoController {
	@Autowired
	RicavoService ricavoService;
	
	@Operation(summary = "inserisce un ricavo nel db", description = "inserisce un ricavo nel db")
	@ApiResponse(responseCode = "200", description = "ricavo inserito")
	@ApiResponse(responseCode = "401,403", description = "Not Authenticated")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@PostMapping(produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity<?> inserisciRicavo(@Valid @RequestBody InsertRicavoRequestDTO dto) throws NotFoundException {
		ricavoService.insertRicavo(dto);
		return ResponseEntity.ok("Ricavo inserito");
	}
	
	@Operation(summary = "modifica un ricavo", description = "modifica un ricavo")
	@ApiResponse(responseCode = "200", description = "modifica avvenuta")
	@ApiResponse(responseCode = "401,403", description = "Not Authenticated")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/modifica-ricavo/{id}")
	public ResponseEntity<?> modificaRicavo(@Valid @PathVariable Long id, @RequestBody InsertRicavoRequestDTO dto) throws NotFoundException {
		ricavoService.updateRicavo(id, dto);
		return ResponseEntity.ok("Ricavo modificato");
	}
	
	@Operation(summary = "elimina un ricavo", description = "elimina un ricavo")
	@ApiResponse(responseCode = "200", description = "eliminazione avvenuta")
	@ApiResponse(responseCode = "401,403", description = "Not Authenticated")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@DeleteMapping("/elimina-ricavo")
	public ResponseEntity<?> eliminaRicavo(@Valid Long id) throws NotFoundException {
		ricavoService.delete(id);
		return ResponseEntity.ok("ricavo eliminato");
	}
	
	@Operation(summary = "ritorna tutti i ricavi", description = "ritorna tutti i ricavi")
	@ApiResponse(responseCode = "200", description = "lista ricavi")
	@ApiResponse(responseCode = "401,403", description = "Not Authenticated")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@GetMapping("/get-all")
	public ResponseEntity<Page<Ricavo>> tuttiRicavi(Pageable page) {
		return ResponseEntity.ok(ricavoService.findAll(page));
	}
	
	@Operation(summary = "ritorna un ricavo", description = "ritorna un ricavo")
	@ApiResponse(responseCode = "200", description = "ricavo")
	@ApiResponse(responseCode = "401,403", description = "Not Authenticated")
//	@PreAuthorize("isAuthenticated()")
//	@SecurityRequirement(name = "bearerAuth")
	@GetMapping("/get-byid/{id}")
	public ResponseEntity<Ricavo> getById(@Valid @PathVariable Long id) throws NotFoundException {
		return ResponseEntity.ok(ricavoService.findById(id));
	}

}
