package it.quofind.application.statovenditevenditore;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface StatoVenditaVenditoreRepository extends PagingAndSortingRepository<StatoVenditaVenditore, Long>{

}
