package it.quofind.application.statovenditecollaboratore;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface StatoVenditaCollaboratoreRepository extends PagingAndSortingRepository<StatoVenditaCollaboratore, Long>{

}
