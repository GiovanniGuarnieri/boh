package it.quofind.application.QRCodeOfferta;

import java.time.LocalDateTime;



import com.fasterxml.jackson.annotation.JsonFormat;


import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class InsertQrRequestDTO {
	static final String DATETIME_PATTERN ="dd/MM/yyyy HH:mm:ss";
	
	private boolean usato;
	
	@JsonFormat(pattern = DATETIME_PATTERN)
	private LocalDateTime dataInizioValidita;
	@JsonFormat(pattern = DATETIME_PATTERN)
	private LocalDateTime dataValidità; 
	private Long offertaId;

}
