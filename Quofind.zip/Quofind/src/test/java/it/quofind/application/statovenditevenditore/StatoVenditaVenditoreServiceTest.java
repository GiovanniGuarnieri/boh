package it.quofind.application.statovenditevenditore;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import it.quofind.application.company.Company;
import it.quofind.application.company.CompanyRepository;
import it.quofind.application.errors.ElementAlreadyPresentException;
import it.quofind.application.errors.NotFoundException;

@SpringBootTest
public class StatoVenditaVenditoreServiceTest {
	@Autowired
	StatoVenditaVenditoreService statoVenditaVenditoreService;
	@Autowired
	StatoVenditaVenditoreRepository statoVenditaVenditoreRepository;
	@Autowired
	CompanyRepository companyRepository;
	
	Pageable pageable = Pageable.ofSize(20);
	

	@Order(1)
	@Test
	@Transactional
	public void  insertStatoVenditaVenditore() throws ElementAlreadyPresentException, NotFoundException {
		InsertStatoVenditaVenditoreRequestDTO dto = new InsertStatoVenditaVenditoreRequestDTO();
		Company co = new Company();
		Company coSaved = companyRepository.save(co);
		dto.setCompanyId(coSaved.getId());
		dto.setAnno(2002);
		dto.setMese(11);
		statoVenditaVenditoreService.insertStatoVenditaVenditore(dto);
		Page<StatoVenditaVenditore> statoVenditaVenditore = statoVenditaVenditoreRepository.findAll(pageable);
		assertThat(statoVenditaVenditore.getNumberOfElements()).isEqualTo(1);
	}
	
	@Order(2)
	@Test
	@Transactional
	public void getAll() throws ElementAlreadyPresentException, NotFoundException {
		InsertStatoVenditaVenditoreRequestDTO dto = new InsertStatoVenditaVenditoreRequestDTO();
		Company co = new Company();
		Company coSaved = companyRepository.save(co);
		dto.setCompanyId(coSaved.getId());
		dto.setAnno(2002);
		dto.setMese(11);
		statoVenditaVenditoreService.insertStatoVenditaVenditore(dto);
	  	InsertStatoVenditaVenditoreRequestDTO dto2 = new InsertStatoVenditaVenditoreRequestDTO();
		Company co2 = new Company();
		Company coSaved2 = companyRepository.save(co2);
		dto2.setCompanyId(coSaved2.getId());
		dto2.setAnno(2002);
		dto2.setMese(11);
		statoVenditaVenditoreService.insertStatoVenditaVenditore(dto2);
		Page statoVenditaVenditore = statoVenditaVenditoreService.findAll(pageable);
		assertThat(statoVenditaVenditore.getNumberOfElements()).isEqualTo(2);
	}
	
	@Order(3)
	@Test
	@Transactional
	public void getByid() throws NotFoundException {
		StatoVenditaVenditore statoVenditaVenditore = new StatoVenditaVenditore();
		Company co = new Company();
		Company coSaved = companyRepository.save(co);
		statoVenditaVenditore.setCompany(coSaved);
		StatoVenditaVenditore saved = statoVenditaVenditoreRepository.save(statoVenditaVenditore);
		StatoVenditaVenditore getted = statoVenditaVenditoreService.findById(saved.getId());
		assertEquals(saved, getted);
	}

	@Order(4)
	@Test
	@Transactional
	public void UpdateStatoVenditaVenditore() throws NotFoundException {
		InsertStatoVenditaVenditoreRequestDTO dto = new InsertStatoVenditaVenditoreRequestDTO();
		Company co = new Company();
		Company coSaved = companyRepository.save(co);
		dto.setCompanyId(coSaved.getId());
		dto.setAnno(2002);
		dto.setMese(11);
		dto.setAttive(false);
		StatoVenditaVenditore statoVenditaVenditore = new StatoVenditaVenditore();
		statoVenditaVenditore.setCompany(coSaved);
		co.getStatoVendite().add(statoVenditaVenditore);
		StatoVenditaVenditore saved = statoVenditaVenditoreRepository.save(statoVenditaVenditore);
		statoVenditaVenditoreService.updateStatoVenditaVenditore(saved.getId(), dto);
		assertFalse(saved.isAttive());
	}
	
	@Order(5)
	@Test
	@Transactional
	public void delete() throws ElementAlreadyPresentException, NotFoundException {
		StatoVenditaVenditore statoVenditaVenditore = new StatoVenditaVenditore();
		StatoVenditaVenditore saved = statoVenditaVenditoreRepository.save(statoVenditaVenditore);
		Page statoVendite = statoVenditaVenditoreService.findAll(pageable);
		assertTrue(statoVendite.getNumberOfElements() == 1);
		statoVenditaVenditoreService.delete(saved.getId());
		statoVendite = statoVenditaVenditoreService.findAll(pageable);
		assertTrue(statoVendite.getNumberOfElements() == 0);
	}

}
