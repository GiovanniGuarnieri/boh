package it.quofind.application.ricavo;

import static org.assertj.core.api.Assertions.*;
import static org.junit.Assert.*;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import it.quofind.application.collaboratore.Collaboratore;
import it.quofind.application.collaboratore.CollaboratoreRepository;
import it.quofind.application.company.Company;
import it.quofind.application.company.CompanyRepository;
import it.quofind.application.errors.ElementAlreadyPresentException;
import it.quofind.application.errors.NotFoundException;

@SpringBootTest
public class RicavoServiceTest {
	@Autowired
	RicavoService ricavoService;
	@Autowired
	RicavoRepository ricavoRepository;
	@Autowired
	CollaboratoreRepository collaboratoreRepository;
	@Autowired
	CompanyRepository companyRepository;
	
	Pageable pageable = Pageable.ofSize(20);
	

	@Order(1)
	@Test
	@Transactional
	public void  insertRicavo() throws ElementAlreadyPresentException, NotFoundException {
		InsertRicavoRequestDTO dto = new InsertRicavoRequestDTO();
		Collaboratore col = new Collaboratore();
		Collaboratore colSaved = collaboratoreRepository.save(col);
		Company co = new Company();
		Company coSaved = companyRepository.save(co);
		dto.setCompanyId(coSaved.getId());
		dto.setCollaboratoreId(colSaved.getId());
		dto.setAnno(2002);
		dto.setMese(11);
	  	ricavoService.insertRicavo(dto);
		Page<Ricavo> ricavo = ricavoRepository.findAll(pageable);
		assertThat(ricavo.getNumberOfElements()).isEqualTo(1);
	}
	
	@Order(2)
	@Test
	@Transactional
	public void getAll() throws ElementAlreadyPresentException, NotFoundException {
		InsertRicavoRequestDTO dto = new InsertRicavoRequestDTO();
		Collaboratore col = new Collaboratore();
		Collaboratore colSaved = collaboratoreRepository.save(col);
		Company co = new Company();
		Company coSaved = companyRepository.save(co);
		dto.setCompanyId(coSaved.getId());
		dto.setCollaboratoreId(colSaved.getId());
		dto.setAnno(2002);
		dto.setMese(11);
	  	ricavoService.insertRicavo(dto);
	  	InsertRicavoRequestDTO dto2 = new InsertRicavoRequestDTO();
		Collaboratore col2 = new Collaboratore();
		Collaboratore colSaved2 = collaboratoreRepository.save(col2);
		Company co2 = new Company();
		Company coSaved2 = companyRepository.save(co2);
		dto2.setCompanyId(coSaved2.getId());
		dto2.setCollaboratoreId(colSaved2.getId());
		dto2.setAnno(2002);
		dto2.setMese(11);
	  	ricavoService.insertRicavo(dto2);
		Page ricavi = ricavoService.findAll(pageable);
		assertThat(ricavi.getNumberOfElements()).isEqualTo(2);
	}
	
	@Order(3)
	@Test
	@Transactional
	public void getByid() throws NotFoundException {
		Ricavo ricavo = new Ricavo();
		Collaboratore col = new Collaboratore();
		Collaboratore colSaved = collaboratoreRepository.save(col);
		Company co = new Company();
		Company coSaved = companyRepository.save(co);
		ricavo.setCollaboratore(colSaved);
		ricavo.setCompany(coSaved);
		Ricavo ricavoSaved = ricavoRepository.save(ricavo);
		Ricavo ricavoGetted = ricavoService.findById(ricavoSaved.getId());
		assertEquals(ricavoSaved, ricavoGetted);
	}

	@Order(4)
	@Test
	@Transactional
	public void UpdateRicavo() throws NotFoundException {
		InsertRicavoRequestDTO dto = new InsertRicavoRequestDTO();
		Collaboratore col = new Collaboratore();
		Collaboratore colSaved = collaboratoreRepository.save(col);
		Company co = new Company();
		Company coSaved = companyRepository.save(co);
		dto.setCompanyId(coSaved.getId());
		dto.setCollaboratoreId(colSaved.getId());
		dto.setTotale(200.0);
		dto.setAnno(2002);
		dto.setMese(11);
		Ricavo ricavo = new Ricavo();
		ricavo.setCompany(coSaved);
		ricavo.setCollaboratore(colSaved);
		co.getRicavi().add(ricavo);
		col.getRicavi().add(ricavo);
		Ricavo ricavoSaved = ricavoRepository.save(ricavo);
		ricavoService.updateRicavo(ricavoSaved.getId(), dto);
		assertEquals(ricavoSaved.getTotale(), 200.0, 0.01);

	}
	@Order(5)
	@Test
	@Transactional
	public void delete() throws ElementAlreadyPresentException, NotFoundException {
		Ricavo ricavo = new Ricavo();
		Ricavo ricavoSaved = ricavoRepository.save(ricavo);
		Page ricavi = ricavoService.findAll(pageable);
		assertTrue(ricavi.getNumberOfElements() == 1);
		ricavoService.delete(ricavoSaved.getId());
		ricavi = ricavoService.findAll(pageable);
		assertTrue(ricavi.getNumberOfElements() == 0);
	}
}
