package it.quofind.application.ricavocashback;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import it.quofind.application.collaboratore.Collaboratore;
import it.quofind.application.collaboratore.CollaboratoreRepository;
import it.quofind.application.company.Company;
import it.quofind.application.company.CompanyRepository;
import it.quofind.application.errors.ElementAlreadyPresentException;
import it.quofind.application.errors.NotFoundException;
import it.quofind.application.user.User;
import it.quofind.application.user.UserRepository;

@SpringBootTest
public class RicavoCashBackServiceTest {
	@Autowired
	RicavoCashBackService ricavoCashBackService;
	@Autowired
	RicavoCashBackRepository ricavoCashBackRepository;
	@Autowired
	CollaboratoreRepository collaboratoreRepository;
	@Autowired
	CompanyRepository companyRepository;
	@Autowired
	UserRepository userRepository;
	
	Pageable pageable = Pageable.ofSize(20);
	

	@Order(1)
	@Test
	@Transactional
	public void  insertRicavoCashBack() throws ElementAlreadyPresentException, NotFoundException {
		InsertRicavoCashBackRequestDTO dto = new InsertRicavoCashBackRequestDTO();
		Collaboratore col = new Collaboratore();
		Collaboratore colSaved = collaboratoreRepository.save(col);
		Company co = new Company();
		Company coSaved = companyRepository.save(co);
		User user = new User();
		user.setUsername("leader");
		User userSaved = userRepository.save(user);
		dto.setCompanyId(coSaved.getId());
		dto.setCollaboratoreId(colSaved.getId());
		dto.setUserId(userSaved.getUsername());
		dto.setAnno(2002);
		dto.setMese(11);
	  	ricavoCashBackService.insertRicavoCashBack(dto);
		Page<RicavoCashBack> ricavoCashBack = ricavoCashBackRepository.findAll(pageable);
		assertThat(ricavoCashBack.getNumberOfElements()).isEqualTo(1);
	}
	
	@Order(2)
	@Test
	@Transactional
	public void getAll() throws ElementAlreadyPresentException, NotFoundException {
		InsertRicavoCashBackRequestDTO dto = new InsertRicavoCashBackRequestDTO();
		Collaboratore col = new Collaboratore();
		Collaboratore colSaved = collaboratoreRepository.save(col);
		Company co = new Company();
		Company coSaved = companyRepository.save(co);
		User user = new User();
		user.setUsername("leader");
		User userSaved = userRepository.save(user);
		dto.setCompanyId(coSaved.getId());
		dto.setCollaboratoreId(colSaved.getId());
		dto.setUserId(userSaved.getUsername());
		dto.setAnno(2002);
		dto.setMese(11);
	  	ricavoCashBackService.insertRicavoCashBack(dto);
	  	InsertRicavoCashBackRequestDTO dto2 = new InsertRicavoCashBackRequestDTO();
		Collaboratore col2 = new Collaboratore();
		Collaboratore colSaved2 = collaboratoreRepository.save(col2);
		Company co2 = new Company();
		Company coSaved2 = companyRepository.save(co2);
		User user2 = new User();
		user2.setUsername("leader2");
		User userSaved2 = userRepository.save(user2);
		dto2.setCompanyId(coSaved2.getId());
		dto2.setCollaboratoreId(colSaved2.getId());
		dto2.setUserId(userSaved2.getUsername());
		dto2.setAnno(2002);
		dto2.setMese(11);
	  	ricavoCashBackService.insertRicavoCashBack(dto2);
		Page ricaviCashBack = ricavoCashBackService.findAll(pageable);
		assertThat(ricaviCashBack.getNumberOfElements()).isEqualTo(2);
	}
	
	@Order(3)
	@Test
	@Transactional
	public void getByid() throws NotFoundException {
		RicavoCashBack ricavoCashBack = new RicavoCashBack();
		Collaboratore col = new Collaboratore();
		Collaboratore colSaved = collaboratoreRepository.save(col);
		Company co = new Company();
		Company coSaved = companyRepository.save(co);
		User user = new User();
		user.setUsername("leader");
		User userSaved = userRepository.save(user);
		ricavoCashBack.setCollaboratore(colSaved);
		ricavoCashBack.setCompany(coSaved);
		ricavoCashBack.setLeaderUser(user);
		RicavoCashBack ricavoCashBackSaved = ricavoCashBackRepository.save(ricavoCashBack);
		RicavoCashBack ricavoCashBackGetted = ricavoCashBackService.findById(ricavoCashBackSaved.getId());
		assertEquals(ricavoCashBackSaved, ricavoCashBackGetted);
	}

	@Order(4)
	@Test
	@Transactional
	public void UpdateRicavoCashBack() throws NotFoundException {
		InsertRicavoCashBackRequestDTO dto = new InsertRicavoCashBackRequestDTO();
		Collaboratore col = new Collaboratore();
		Collaboratore colSaved = collaboratoreRepository.save(col);
		Company co = new Company();
		Company coSaved = companyRepository.save(co);
		User user = new User();
		user.setUsername("leader");
		User userSaved = userRepository.save(user);
		dto.setCompanyId(coSaved.getId());
		dto.setCollaboratoreId(colSaved.getId());
		dto.setUserId(userSaved.getUsername());
		dto.setTotale(42.0);
		dto.setAnno(2002);
		dto.setMese(11);
		RicavoCashBack ricavoCashBack = new RicavoCashBack();
		ricavoCashBack.setCompany(coSaved);
		ricavoCashBack.setCollaboratore(colSaved);
		ricavoCashBack.setLeaderUser(userSaved);
		co.getRicaviCashBack().add(ricavoCashBack);
		col.getRicaviCashBack().add(ricavoCashBack);
		user.getRicaviCashBack().add(ricavoCashBack);
		RicavoCashBack ricavoCashBackSaved = ricavoCashBackRepository.save(ricavoCashBack);
		ricavoCashBackService.updateRicavoCashBack(ricavoCashBackSaved.getId(), dto);
		assertEquals(ricavoCashBackSaved.getTotale(), 42.0, 0.01);

	}
	@Order(5)
	@Test
	@Transactional
	public void delete() throws ElementAlreadyPresentException, NotFoundException {
		RicavoCashBack ricavoCashBack = new RicavoCashBack();
		RicavoCashBack ricavoCashBackSaved = ricavoCashBackRepository.save(ricavoCashBack);
		Page ricaviCashBack = ricavoCashBackService.findAll(pageable);
		assertTrue(ricaviCashBack.getNumberOfElements() == 1);
		ricavoCashBackService.delete(ricavoCashBackSaved.getId());
		ricaviCashBack = ricavoCashBackService.findAll(pageable);
		assertTrue(ricaviCashBack.getNumberOfElements() == 0);
	}
}
