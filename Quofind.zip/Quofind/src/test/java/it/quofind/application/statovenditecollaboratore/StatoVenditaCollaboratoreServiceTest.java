package it.quofind.application.statovenditecollaboratore;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import it.quofind.application.collaboratore.Collaboratore;
import it.quofind.application.collaboratore.CollaboratoreRepository;
import it.quofind.application.errors.ElementAlreadyPresentException;
import it.quofind.application.errors.NotFoundException;

@SpringBootTest
public class StatoVenditaCollaboratoreServiceTest {
	@Autowired
	StatoVenditaCollaboratoreService statoVenditaCollaboratoreService;
	@Autowired
	StatoVenditaCollaboratoreRepository statoVenditaCollaboratoreRepository;
	@Autowired
	CollaboratoreRepository collaboratoreRepository;
	
	Pageable pageable = Pageable.ofSize(20);
	

	@Order(1)
	@Test
	@Transactional
	public void  insertStatoVenditaCollaboratore() throws ElementAlreadyPresentException, NotFoundException {
		InsertStatoVenditaCollaboratoreRequestDTO dto = new InsertStatoVenditaCollaboratoreRequestDTO();
		Collaboratore col = new Collaboratore();
		Collaboratore colSaved = collaboratoreRepository.save(col);
		dto.setCollaboratoreId(colSaved.getId());
		dto.setAnno(2002);
		dto.setMese(11);
		statoVenditaCollaboratoreService.insertStatoVenditaCollaboratore(dto);
		Page<StatoVenditaCollaboratore> statoVenditaCollaboratore = statoVenditaCollaboratoreRepository.findAll(pageable);
		assertThat(statoVenditaCollaboratore.getNumberOfElements()).isEqualTo(1);
	}
	
	@Order(2)
	@Test
	@Transactional
	public void getAll() throws ElementAlreadyPresentException, NotFoundException {
		InsertStatoVenditaCollaboratoreRequestDTO dto = new InsertStatoVenditaCollaboratoreRequestDTO();
		Collaboratore col = new Collaboratore();
		Collaboratore colSaved = collaboratoreRepository.save(col);
		dto.setCollaboratoreId(colSaved.getId());
		dto.setAnno(2002);
		dto.setMese(11);
		statoVenditaCollaboratoreService.insertStatoVenditaCollaboratore(dto);
	  	InsertStatoVenditaCollaboratoreRequestDTO dto2 = new InsertStatoVenditaCollaboratoreRequestDTO();
		Collaboratore col2 = new Collaboratore();
		Collaboratore colSaved2 = collaboratoreRepository.save(col2);
		dto2.setCollaboratoreId(colSaved2.getId());
		dto2.setAnno(2002);
		dto2.setMese(11);
		statoVenditaCollaboratoreService.insertStatoVenditaCollaboratore(dto2);
		Page statoVenditaCollaboratore = statoVenditaCollaboratoreService.findAll(pageable);
		assertThat(statoVenditaCollaboratore.getNumberOfElements()).isEqualTo(2);
	}
	
	@Order(3)
	@Test
	@Transactional
	public void getByid() throws NotFoundException {
		StatoVenditaCollaboratore statoVenditaCollaboratore = new StatoVenditaCollaboratore();
		Collaboratore col = new Collaboratore();
		Collaboratore colSaved = collaboratoreRepository.save(col);
		statoVenditaCollaboratore.setCollaboratore(colSaved);
		StatoVenditaCollaboratore saved = statoVenditaCollaboratoreRepository.save(statoVenditaCollaboratore);
		StatoVenditaCollaboratore getted = statoVenditaCollaboratoreService.findById(saved.getId());
		assertEquals(saved, getted);
	}

	@Order(4)
	@Test
	@Transactional
	public void UpdateStatoVenditaCollaboratore() throws NotFoundException {
		InsertStatoVenditaCollaboratoreRequestDTO dto = new InsertStatoVenditaCollaboratoreRequestDTO();
		Collaboratore col = new Collaboratore();
		Collaboratore colSaved = collaboratoreRepository.save(col);
		dto.setCollaboratoreId(colSaved.getId());
		dto.setAnno(2002);
		dto.setMese(11);
		dto.setAttive(false);
		StatoVenditaCollaboratore statoVenditaCollaboratore = new StatoVenditaCollaboratore();
		statoVenditaCollaboratore.setCollaboratore(colSaved);
		col.getStatoVendite().add(statoVenditaCollaboratore);
		StatoVenditaCollaboratore saved = statoVenditaCollaboratoreRepository.save(statoVenditaCollaboratore);
		statoVenditaCollaboratoreService.updateStatoVenditaCollaboratore(saved.getId(), dto);
		assertFalse(saved.isAttive());
	}
	
	@Order(5)
	@Test
	@Transactional
	public void delete() throws ElementAlreadyPresentException, NotFoundException {
		StatoVenditaCollaboratore statoVenditaCollaboratore = new StatoVenditaCollaboratore();
		StatoVenditaCollaboratore saved = statoVenditaCollaboratoreRepository.save(statoVenditaCollaboratore);
		Page statoVendite = statoVenditaCollaboratoreService.findAll(pageable);
		assertTrue(statoVendite.getNumberOfElements() == 1);
		statoVenditaCollaboratoreService.delete(saved.getId());
		statoVendite = statoVenditaCollaboratoreService.findAll(pageable);
		assertTrue(statoVendite.getNumberOfElements() == 0);
	}
}
